# TrendShorts v2.0 — Full-Stack YouTube Shorts Engine

**AI-powered YouTube Shorts generation with real Google Trends, InVideo AI video rendering (9:16), and YouTube autopilot posting.**

---

## Project Structure

```
trendshorts/
├── frontend/               ← Open index.html in a browser (or serve with Live Server)
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── api.js          ← Backend API client (auto-connects to backend)
│       ├── app.js          ← Full application logic + KENPACHI splash
│       └── data.js         ← Minimal stub (real data comes from backend)
│
└── backend/                ← Node.js Express server
    ├── src/
    │   ├── server.js
    │   ├── routes/         ← auth, trends, generator, youtube, shorts, analytics, settings
    │   ├── services/       ← trendsService, youtubeService, generatorService, scheduler
    │   └── utils/          ← database (SQLite), logger (Winston)
    ├── scripts/setup.js    ← Interactive first-run wizard
    ├── package.json
    └── .env.example
```

---

## Quick Start

### Step 1 — Run the Backend

```bash
cd backend
npm install
npm run setup        # Interactive wizard — creates your .env file
npm run dev          # Start server on http://localhost:3001
```

### Step 2 — Open the Frontend

Open `frontend/index.html` directly in your browser, **or** use VS Code Live Server (recommended) pointing at the `frontend/` folder.

The KENPACHI splash screen will animate on load. The frontend auto-detects the backend: if it is running, live data flows in; if not, the app runs in demo mode with mock trends.

---

## API Keys Required

| Service | Purpose | Where to get it |
|---|---|---|
| Google OAuth 2.0 | YouTube channel connection + video upload | [console.cloud.google.com](https://console.cloud.google.com) — enable YouTube Data API v3 |
| SerpAPI | Real Google Trends data | [serpapi.com](https://serpapi.com) — free tier: 100 searches/month |
| OpenAI | AI-powered script generation | [platform.openai.com](https://platform.openai.com) — optional (falls back to templates) |

All keys are entered during `npm run setup` and stored in `backend/.env`.

---

## InVideo AI — Video Rendering (9:16)

All video rendering in TrendShorts uses **InVideo AI** at [https://www.invideoai.org/](https://www.invideoai.org/). Every Short is rendered in **9:16 portrait format** (1080×1920px), optimised for YouTube Shorts.

**Workflow:**
1. Generate a Short in the Generator tab — you receive a complete script, storyboard, and hashtags.
2. Click **"Open in InVideo AI"** — the app opens InVideo in a new tab and copies your prompt to the clipboard.
3. Paste the prompt into InVideo AI's prompt box, select **9:16 (Vertical / Shorts)**, and generate your video.
4. Export the MP4 from InVideo AI.
5. Return to TrendShorts and upload the MP4 via the API (`POST /api/youtube/upload/:shortId`) to post or schedule it on YouTube.

---

## YouTube Autopilot

When enabled in Settings, the scheduler runs every 6 hours, picks the top trending topics, generates Short scripts, and schedules them for posting. For autopilot posting to work, MP4 files must be present in `backend/data/videos/{shortId}.mp4` — integrate InVideo AI's export step into your workflow to close this loop.

Enable autopilot via the Settings page or directly:

```
PUT http://localhost:3001/api/settings
{ "autopilot_enabled": "true", "autopilot_auto_post": "true", "autopilot_region": "US" }
```

---

## Google Cloud Setup (5 minutes)

1. Go to [console.cloud.google.com](https://console.cloud.google.com) and create a project.
2. Enable **YouTube Data API v3** under APIs & Services → Library.
3. Create an OAuth 2.0 Client ID (Web application type).
4. Add `http://localhost:3001/api/auth/youtube/callback` as an Authorised Redirect URI.
5. Copy the Client ID and Secret into your `.env`.

---

## Deployment

For production deployment on **Railway** or **Render**, change these `.env` values:

```
NODE_ENV=production
FRONTEND_URL=https://your-frontend-domain.com
GOOGLE_REDIRECT_URI=https://your-backend-domain.com/api/auth/youtube/callback
```

Update the Google Cloud redirect URI to match. The frontend's `api.js` will auto-connect to the backend if you set `window.TRENDSHORTS_API_URL` before the script loads.

---

## API Reference (key endpoints)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Server health and connection status |
| GET | `/api/auth/youtube/url` | Get Google OAuth consent URL |
| GET | `/api/auth/youtube/status` | Check if channel is connected |
| GET | `/api/trends?region=US&category=all` | Fetch live Google Trends |
| POST | `/api/generator/generate` | Generate Short script via AI |
| GET | `/api/shorts` | List Shorts library |
| POST | `/api/youtube/upload/:id` | Upload MP4 file for a Short |
| POST | `/api/youtube/post/:id` | Post Short to YouTube immediately |
| POST | `/api/youtube/schedule/:id` | Schedule a Short for future posting |
| GET | `/api/invideo/info` | InVideo AI integration details |
| PUT | `/api/settings` | Update app settings (incl. autopilot) |
