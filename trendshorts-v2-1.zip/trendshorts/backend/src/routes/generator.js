// ============================================================
//  routes/generator.js
// ============================================================
const express   = require('express');
const router    = express.Router();
const generator = require('../services/generatorService');
const db        = require('../utils/database');

// POST /api/generator/generate
router.post('/generate', async (req, res) => {
  const {
    topic, category = 'general', tone = 'educational',
    duration = 30, style = 'Talking Head',
    audience = 'General audience', keywords = [],
    trendId = null,
  } = req.body;

  if (!topic?.trim()) return res.status(400).json({ error: 'topic is required' });

  try {
    const result = await generator.generateShort({
      topic: topic.trim(), category, tone,
      duration: parseInt(duration), style, audience, keywords, trendId,
    });
    res.json({ success: true, short: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/generator/:id  — retrieve a generated Short
router.get('/:id', (req, res) => {
  const short = generator.getShortById(req.params.id);
  if (!short) return res.status(404).json({ error: 'Short not found' });
  res.json({ success: true, short });
});

module.exports = router;
