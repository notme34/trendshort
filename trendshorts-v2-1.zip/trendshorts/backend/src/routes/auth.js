// ============================================================
//  routes/auth.js — YouTube OAuth flow
// ============================================================
const express  = require('express');
const router   = express.Router();
const youtube  = require('../services/youtubeService');
const logger   = require('../utils/logger');

// GET /api/auth/youtube/url  — get the Google OAuth consent URL
router.get('/youtube/url', (req, res) => {
  try {
    if (!process.env.GOOGLE_CLIENT_ID) {
      return res.status(503).json({
        error: 'Google OAuth not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env',
      });
    }
    const url = youtube.getAuthUrl();
    res.json({ url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/auth/youtube/callback  — OAuth callback from Google
router.get('/youtube/callback', async (req, res) => {
  const { code, error } = req.query;

  if (error) {
    logger.warn(`YouTube OAuth denied: ${error}`);
    return res.redirect(`${process.env.FRONTEND_URL}/?auth=denied`);
  }

  if (!code) {
    return res.redirect(`${process.env.FRONTEND_URL}/?auth=error&reason=no_code`);
  }

  try {
    const tokens  = await youtube.exchangeCode(code);
    const channel = await youtube.getChannelInfo(tokens);

    // Persist to DB and session
    youtube.saveChannelToDB(channel, tokens);
    req.session.youtubeTokens  = tokens;
    req.session.youtubeChannel = channel;

    logger.info(`YouTube channel connected: ${channel.name} (${channel.id})`);
    res.redirect(`${process.env.FRONTEND_URL}/?auth=success&channel=${encodeURIComponent(channel.name)}`);
  } catch (err) {
    logger.error(`YouTube OAuth callback error: ${err.message}`);
    res.redirect(`${process.env.FRONTEND_URL}/?auth=error&reason=${encodeURIComponent(err.message)}`);
  }
});

// GET /api/auth/youtube/status  — check if a channel is connected
router.get('/youtube/status', (req, res) => {
  const stored = youtube.getStoredChannel();
  if (!stored) return res.json({ connected: false });

  res.json({
    connected: true,
    channel:   stored.channel,
  });
});

// POST /api/auth/youtube/disconnect
router.post('/youtube/disconnect', (req, res) => {
  youtube.disconnectChannel();
  req.session.youtubeTokens  = null;
  req.session.youtubeChannel = null;
  logger.info('YouTube channel disconnected');
  res.json({ success: true });
});

// POST /api/auth/youtube/refresh  — refresh channel stats
router.post('/youtube/refresh', async (req, res) => {
  const stored = youtube.getStoredChannel();
  if (!stored) return res.status(401).json({ error: 'No channel connected' });

  try {
    const channel = await youtube.getChannelInfo(stored.tokens);
    youtube.saveChannelToDB(channel, stored.tokens);
    res.json({ success: true, channel });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
