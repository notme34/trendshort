// ============================================================
//  services/trendsService.js
//  Fetches real Google Trends data via SerpAPI.
//  SerpAPI free tier: 100 searches/month
//  https://serpapi.com/google-trends-api
// ============================================================
const axios  = require('axios');
const db     = require('../utils/database');
const logger = require('../utils/logger');

const SERPAPI_KEY = process.env.SERPAPI_KEY;
const CACHE_TTL   = 2 * 60 * 60; // 2 hours in seconds

// Category → SerpAPI category code mapping
const CATEGORY_MAP = {
  technology:    '5',
  entertainment: '3',
  sports:        '20',
  science:       '8',
  health:        '45',
  business:      '12',
  gaming:        '8-1328',
  food:          '71',
  travel:        '66',
  fashion:       '185',
};

// ── Main public function ──────────────────────────────────────

/**
 * Returns trending topics for a given region and (optional) category.
 * Results are cached in SQLite for CACHE_TTL seconds.
 */
async function getTrends({ region = 'US', category = 'all', forceRefresh = false } = {}) {
  // Return cached results if fresh enough
  if (!forceRefresh) {
    const cached = getCachedTrends(region, category);
    if (cached.length > 0) return cached;
  }

  if (!SERPAPI_KEY) {
    logger.warn('SERPAPI_KEY not set — returning mock trends');
    return getMockTrends(region, category);
  }

  try {
    const fresh = await fetchFromSerpAPI(region, category);
    saveTrends(fresh, region);
    return fresh;
  } catch (err) {
    logger.error(`SerpAPI fetch failed: ${err.message}`);
    // Fall back to whatever is in the cache, even if stale
    const stale = getCachedTrends(region, category, true);
    return stale.length > 0 ? stale : getMockTrends(region, category);
  }
}

// ── SerpAPI call ──────────────────────────────────────────────

async function fetchFromSerpAPI(region, category) {
  const results = [];

  // Fetch trending searches (real-time)
  const realtime = await axios.get('https://serpapi.com/search', {
    params: {
      engine:    'google_trends_trending_now',
      geo:       region,
      hl:        'en',
      api_key:   SERPAPI_KEY,
    },
    timeout: 15000,
  });

  const items = realtime.data?.trending_searches || [];

  for (const item of items.slice(0, 30)) {
    const trend = {
      name:        item.query || item.title || 'Unknown Trend',
      category:    classifyCategory(item.query || ''),
      volume:      formatVolume(item.traffic || item.formattedTraffic),
      volume_num:  parseVolume(item.traffic || item.formattedTraffic),
      change_pct:  item.percent_change ? `+${item.percent_change}%` : '+100%',
      change_type: item.percent_change > 200 ? 'hot' : 'rising',
      score:       Math.min(100, Math.round((parseVolume(item.traffic) / 500000) * 100) || 50),
      description: item.snippet || item.articles?.[0]?.snippet || `Trending topic: ${item.query}`,
      tags:        extractTags(item),
      sparkline:   generateSparkline(),
      fetched_at:  Math.floor(Date.now() / 1000),
    };
    results.push(trend);
  }

  // If a specific category was requested, also fetch category-specific trends
  if (category !== 'all' && CATEGORY_MAP[category]) {
    try {
      const catRes = await axios.get('https://serpapi.com/search', {
        params: {
          engine:   'google_trends',
          q:        getCategoryQuery(category),
          geo:      region,
          data_type:'TIMESERIES',
          hl:       'en',
          api_key:  SERPAPI_KEY,
        },
        timeout: 15000,
      });

      const related = catRes.data?.related_topics?.rising || [];
      for (const t of related.slice(0, 5)) {
        results.push({
          name:        t.topic?.title || t.query,
          category,
          volume:      formatVolume(t.value),
          volume_num:  t.value * 10000 || 50000,
          change_pct:  t.formattedValue || '+50%',
          change_type: 'rising',
          score:       Math.min(100, t.value || 50),
          description: t.topic?.type || `Rising ${category} trend`,
          tags:        [`#${category}`, `#trending`, `#${t.topic?.title?.replace(/\s+/g,'') || 'trend'}`],
          sparkline:   generateSparkline(),
          fetched_at:  Math.floor(Date.now() / 1000),
        });
      }
    } catch (e) {
      logger.warn(`Category-specific fetch failed for ${category}: ${e.message}`);
    }
  }

  return results;
}

// ── Database helpers ──────────────────────────────────────────

function saveTrends(trends, region) {
  // Delete old trends for this region
  db.run('DELETE FROM trends WHERE region = ?', [region]);

  const insert = db.run.bind(db);
  db.transaction(() => {
    for (const t of trends) {
      insert(`
        INSERT INTO trends
          (name, category, volume, volume_num, change_pct, change_type,
           score, description, tags, region, fetched_at, sparkline)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
      `, [
        t.name, t.category, t.volume, t.volume_num,
        t.change_pct, t.change_type, t.score, t.description,
        JSON.stringify(t.tags || []), region,
        t.fetched_at, JSON.stringify(t.sparkline || []),
      ]);
    }
  });

  logger.info(`Saved ${trends.length} trends for region ${region}`);
}

function getCachedTrends(region, category, ignoreExpiry = false) {
  const cutoff = ignoreExpiry ? 0 : Math.floor(Date.now() / 1000) - CACHE_TTL;
  const cat    = category === 'all' ? null : category;

  const rows = cat
    ? db.all(
        'SELECT * FROM trends WHERE region = ? AND category = ? AND fetched_at > ? ORDER BY score DESC',
        [region, cat, cutoff]
      )
    : db.all(
        'SELECT * FROM trends WHERE region = ? AND fetched_at > ? ORDER BY score DESC',
        [region, cutoff]
      );

  return rows.map(parseTrendRow);
}

function parseTrendRow(row) {
  return {
    ...row,
    tags:      safeJsonParse(row.tags, []),
    sparkline: safeJsonParse(row.sparkline, []),
  };
}

// ── Search trends ─────────────────────────────────────────────

async function searchTrends(query, region = 'US') {
  if (!SERPAPI_KEY) return [];
  try {
    const res = await axios.get('https://serpapi.com/search', {
      params: {
        engine:    'google_trends',
        q:         query,
        geo:       region,
        data_type: 'TIMESERIES',
        hl:        'en',
        api_key:   SERPAPI_KEY,
      },
      timeout: 15000,
    });

    const interest = res.data?.interest_over_time?.timeline_data || [];
    return {
      query,
      interest_over_time: interest.map(p => ({
        date:  p.date,
        value: p.values?.[0]?.extracted_value || 0,
      })),
      related_topics:   res.data?.related_topics?.top?.slice(0, 5) || [],
      related_queries:  res.data?.related_queries?.top?.slice(0, 5) || [],
    };
  } catch (err) {
    logger.error(`Trend search failed: ${err.message}`);
    return { query, interest_over_time: [], related_topics: [], related_queries: [] };
  }
}

// ── Helpers ───────────────────────────────────────────────────

function classifyCategory(text) {
  const t = text.toLowerCase();
  if (/\b(ai|tech|software|app|iphone|android|google|microsoft|openai|robot)\b/.test(t)) return 'technology';
  if (/\b(movie|film|music|singer|actor|netflix|spotify|concert|celebrity)\b/.test(t)) return 'entertainment';
  if (/\b(nba|nfl|soccer|football|tennis|olympic|game|match|champion)\b/.test(t)) return 'sports';
  if (/\b(science|space|nasa|climate|research|discovery|physics|biology)\b/.test(t)) return 'science';
  if (/\b(health|diet|vaccine|covid|mental|fitness|wellness|medical)\b/.test(t)) return 'health';
  if (/\b(stock|market|economy|crypto|bitcoin|invest|business|startup)\b/.test(t)) return 'business';
  if (/\b(game|gaming|playstation|xbox|nintendo|esport|fortnite|minecraft)\b/.test(t)) return 'gaming';
  if (/\b(food|recipe|restaurant|cook|eat|cuisine|diet|meal)\b/.test(t)) return 'food';
  if (/\b(travel|vacation|hotel|flight|destination|trip|tourism)\b/.test(t)) return 'travel';
  if (/\b(fashion|style|clothing|outfit|designer|model|trend)\b/.test(t)) return 'fashion';
  return 'general';
}

function formatVolume(raw) {
  if (!raw) return '< 5K';
  const str = String(raw);
  if (str.includes('K') || str.includes('M')) return str;
  const n = parseInt(str.replace(/[^0-9]/g, '')) || 0;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(0)}K`;
  return `${n}`;
}

function parseVolume(raw) {
  if (!raw) return 5000;
  const str = String(raw).toUpperCase();
  if (str.includes('M')) return parseFloat(str) * 1_000_000;
  if (str.includes('K')) return parseFloat(str) * 1_000;
  return parseInt(str.replace(/[^0-9]/g, '')) || 5000;
}

function extractTags(item) {
  const tags = [`#${(item.query || '').replace(/\s+/g, '')}`];
  if (item.articles) {
    item.articles.slice(0, 2).forEach(a => {
      const words = (a.title || '').split(' ').slice(0, 3);
      tags.push(`#${words.join('')}`);
    });
  }
  return [...new Set(tags)].slice(0, 5);
}

function generateSparkline() {
  // 7-day simulated sparkline data
  return Array.from({ length: 7 }, () => Math.floor(Math.random() * 80) + 20);
}

function getCategoryQuery(category) {
  const queries = {
    technology: 'artificial intelligence technology',
    entertainment: 'movies music celebrities',
    sports: 'sports football basketball',
    science: 'science space discovery',
    health: 'health wellness fitness',
    business: 'business economy markets',
    gaming: 'video games gaming',
    food: 'food recipes restaurants',
    travel: 'travel vacation destinations',
    fashion: 'fashion style trends',
  };
  return queries[category] || category;
}

function safeJsonParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

// ── Mock data fallback ────────────────────────────────────────

function getMockTrends(region, category) {
  const all = [
    { name: 'AI Agents Going Mainstream', category: 'technology', volume: '2.4M', volume_num: 2400000, change_pct: '+340%', change_type: 'hot', score: 96, description: 'AI agents are being used to automate complex workflows across all industries.', tags: ['#AIAgents', '#OpenAI', '#Automation'], sparkline: [20,35,45,60,75,88,96], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'GPT-5 Release Rumours', category: 'technology', volume: '1.8M', volume_num: 1800000, change_pct: '+210%', change_type: 'hot', score: 91, description: 'Speculation about the next major language model from OpenAI is reaching fever pitch.', tags: ['#GPT5', '#OpenAI', '#LLM'], sparkline: [10,25,40,55,70,85,91], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'Squid Game Season 3', category: 'entertainment', volume: '3.1M', volume_num: 3100000, change_pct: '+480%', change_type: 'hot', score: 98, description: 'Netflix confirms the third and final season of the global phenomenon.', tags: ['#SquidGame', '#Netflix', '#Korean'], sparkline: [15,30,50,70,85,95,98], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'Champions League Final', category: 'sports', volume: '2.9M', volume_num: 2900000, change_pct: '+290%', change_type: 'hot', score: 95, description: 'Europe\'s biggest club football match draws massive global audience.', tags: ['#UCLFinal', '#Football', '#UEFA'], sparkline: [30,45,55,70,80,90,95], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'James Webb New Discovery', category: 'science', volume: '890K', volume_num: 890000, change_pct: '+150%', change_type: 'rising', score: 79, description: 'The James Webb Space Telescope reveals an Earth-like atmosphere on a distant exoplanet.', tags: ['#JWST', '#Space', '#Exoplanet'], sparkline: [20,30,40,55,65,72,79], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'Ozempic Weight Loss Results', category: 'health', volume: '1.2M', volume_num: 1200000, change_pct: '+180%', change_type: 'rising', score: 85, description: 'New clinical data on GLP-1 drugs shows unprecedented long-term weight loss outcomes.', tags: ['#Ozempic', '#WeightLoss', '#Health'], sparkline: [25,38,50,62,72,80,85], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'Bitcoin ETF New Highs', category: 'business', volume: '1.5M', volume_num: 1500000, change_pct: '+220%', change_type: 'hot', score: 88, description: 'Spot Bitcoin ETF inflows hit record highs as institutional demand accelerates.', tags: ['#Bitcoin', '#ETF', '#Crypto'], sparkline: [22,34,48,60,72,82,88], fetched_at: Math.floor(Date.now()/1000) },
    { name: 'GTA VI Release Date', category: 'gaming', volume: '4.2M', volume_num: 4200000, change_pct: '+600%', change_type: 'hot', score: 99, description: 'Rockstar Games officially confirms the GTA VI launch window, sending the internet into meltdown.', tags: ['#GTAVI', '#Rockstar', '#Gaming'], sparkline: [40,55,68,80,90,96,99], fetched_at: Math.floor(Date.now()/1000) },
  ];

  if (category === 'all') return all;
  return all.filter(t => t.category === category);
}

module.exports = { getTrends, searchTrends };
