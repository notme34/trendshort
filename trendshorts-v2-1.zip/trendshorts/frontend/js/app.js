// ============================================================
//  app.js — TrendShorts Main Application Logic
// ============================================================

// ── KENPACHI SPLASH ───────────────────────────────────────────
(function initSplash() {
  const TEXT     = 'KENPACHI';
  const textEl   = document.getElementById('kenpachi-text');
  const cursorEl = document.getElementById('kenpachi-cursor');
  const barEl    = document.getElementById('splash-bar');
  const statusEl = document.getElementById('splash-status');
  const tagEl    = document.getElementById('splash-tagline');
  const splash   = document.getElementById('splash');
  const app      = document.getElementById('app');

  const statuses = [
    'INITIALISING SYSTEMS...',
    'LOADING TREND ENGINE...',
    'CONNECTING TO GOOGLE TRENDS...',
    'PREPARING AI GENERATOR...',
    'LINKING INVIDEO AI...',
    'READY.',
  ];

  let charIdx = 0;
  let statusIdx = 0;
  let progress = 0;

  // Type out KENPACHI letter by letter
  const typeInterval = setInterval(() => {
    if (charIdx < TEXT.length) {
      textEl.textContent += TEXT[charIdx];
      charIdx++;
    } else {
      clearInterval(typeInterval);
      cursorEl.style.display = 'none';
      tagEl.classList.add('visible');
      startProgressBar();
    }
  }, 100);

  function startProgressBar() {
    const totalDuration = 2200; // ms
    const steps = 60;
    const stepTime = totalDuration / steps;

    const prog = setInterval(() => {
      progress = Math.min(100, progress + (100 / steps) + (Math.random() * 2 - 1));
      barEl.style.width = progress + '%';

      // Cycle status messages
      const newIdx = Math.floor((progress / 100) * statuses.length);
      if (newIdx !== statusIdx && newIdx < statuses.length) {
        statusIdx = newIdx;
        statusEl.textContent = statuses[statusIdx];
      }

      if (progress >= 100) {
        clearInterval(prog);
        barEl.style.width = '100%';
        statusEl.textContent = 'READY.';
        setTimeout(exitSplash, 400);
      }
    }, stepTime);
  }

  function exitSplash() {
    splash.classList.add('splash-exit');
    app.classList.remove('app-hidden');
    app.classList.add('app-visible');
    setTimeout(() => { splash.style.display = 'none'; }, 650);
    App.init();
  }
})();

// ── APP NAMESPACE ─────────────────────────────────────────────
const App = (function () {
  const API = window.TrendShortsAPI || null;
  const Auth = window.TrendShortsAuth || null;

  let currentPage  = 'dashboard';
  let currentRegion = 'US';
  let trendsData   = [];
  let currentShort = null;
  let ytConnected  = false;
  let ytChannel    = null;
  let trendPage    = 1;
  const TRENDS_PER_PAGE = 12;

  // ── Init ────────────────────────────────────────────────────
  async function init() {
    bindNav();
    bindTopbar();
    bindGenerator();
    bindModal();
    bindLibrary();
    bindSettings();

    // Check YouTube connection
    await checkYouTubeStatus();

    // Load dashboard data
    await loadDashboard();

    // Listen for OAuth callback result
    window.addEventListener('youtube:connected', (e) => {
      showToast(`YouTube connected: ${e.detail.channelName}`);
      checkYouTubeStatus();
    });
  }

  // ── Navigation ──────────────────────────────────────────────
  function bindNav() {
    document.querySelectorAll('.nav-item, [data-page]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        const page = el.dataset.page;
        if (page) navigateTo(page);
      });
    });
  }

  function navigateTo(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById(`page-${page}`)?.classList.add('active');
    document.querySelector(`.nav-item[data-page="${page}"]`)?.classList.add('active');
    currentPage = page;

    if (page === 'trends' && trendsData.length === 0) loadTrends();
    if (page === 'analytics') loadAnalytics();
    if (page === 'library')   loadLibrary();
    if (page === 'settings')  loadSettingsPage();
  }

  // ── Topbar ───────────────────────────────────────────────────
  function bindTopbar() {
    document.getElementById('sidebarToggle')?.addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });
    document.getElementById('btnRefreshTrends')?.addEventListener('click', async () => {
      const btn = document.getElementById('btnRefreshTrends');
      btn.classList.add('spinning');
      if (API) await API.refreshTrends().catch(() => {});
      await loadTrends(true);
      btn.classList.remove('spinning');
      showToast('Trends refreshed!');
    });
    document.getElementById('regionSelect')?.addEventListener('change', (e) => {
      currentRegion = e.target.value;
      loadTrends(true);
    });
    document.getElementById('globalSearch')?.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      if (q.length < 2) return;
      if (currentPage === 'trends') filterTrends(q);
    });
  }

  // ── Dashboard ─────────────────────────────────────────────────
  async function loadDashboard() {
    try {
      let trends = [];
      let stats  = { total: '–', posted: '–', draft: '–' };

      if (API && window.__backendReady) {
        trends = await API.getTrends({ region: currentRegion }).catch(() => []);
        stats  = await API.getShortStats().catch(() => stats);
      } else {
        trends = getMockTrends();
      }

      trendsData = trends;

      document.getElementById('statTrends').textContent = trends.length || '–';
      document.getElementById('statShorts').textContent = stats.total || '–';
      document.getElementById('statPosted').textContent = stats.posted || '–';
      document.getElementById('statViews').textContent  = '–';

      renderTopTrends(trends.slice(0, 5));
      renderRecentShorts();
      renderDashboardCharts(trends);
    } catch (e) {
      console.warn('Dashboard load error:', e);
    }
  }

  function renderTopTrends(trends) {
    const ul = document.getElementById('topTrendsList');
    if (!ul) return;
    ul.innerHTML = trends.map((t, i) => `
      <li class="top-trend-item" data-trend-id="${t.id || i}" onclick="App.quickGenerate('${(t.name||'').replace(/'/g,"\\'")}','${t.category||'general'}')">
        <span class="trend-rank">#${i + 1}</span>
        <span class="trend-name">${t.name}</span>
        <span class="trend-vol">${t.volume || ''}</span>
      </li>
    `).join('');
  }

  function renderRecentShorts() {
    const list = document.getElementById('recentShortsList');
    if (!list) return;
    if (API && window.__backendReady) {
      API.getShorts({ limit: 4 }).then(res => {
        const shorts = res.shorts || [];
        if (!shorts.length) {
          list.innerHTML = '<p style="color:var(--text-muted);font-size:13px;text-align:center;padding:20px">No Shorts created yet. Generate your first one!</p>';
          return;
        }
        list.innerHTML = shorts.map(s => `
          <div class="recent-short-item">
            <div class="recent-thumb">${getCatEmoji(s.category)}</div>
            <div class="recent-info">
              <div class="recent-title">${s.title}</div>
              <div class="recent-meta">${s.category} · ${s.duration || '30s'}</div>
            </div>
            <span class="status-pill ${s.status}">${s.status}</span>
          </div>
        `).join('');
      }).catch(() => {
        list.innerHTML = '';
      });
    }
  }

  function renderDashboardCharts(trends) {
    if (typeof Chart === 'undefined') return;

    // Line chart — trend scores over a simulated 7-day period
    const ctx1 = document.getElementById('trendChart');
    if (ctx1) {
      Chart.getChart(ctx1)?.destroy();
      const top5 = trends.slice(0, 5);
      const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const colors = ['#00ff88','#3b82f6','#f5c400','#a855f7','#ff2244'];
      new Chart(ctx1, {
        type: 'line',
        data: {
          labels,
          datasets: top5.map((t, i) => ({
            label: t.name.slice(0, 20),
            data: (t.sparkline || Array.from({length:7},()=>Math.floor(Math.random()*70)+20)),
            borderColor: colors[i],
            backgroundColor: colors[i] + '15',
            fill: true,
            tension: 0.4,
            pointRadius: 3,
          }))
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { grid: { color:'rgba(255,255,255,0.04)' }, ticks: { color:'#6a7fa8', font:{family:'Share Tech Mono',size:11} } },
            y: { grid: { color:'rgba(255,255,255,0.04)' }, ticks: { color:'#6a7fa8', font:{family:'Share Tech Mono',size:11} } },
          }
        }
      });
    }

    // Donut — categories
    const ctx2 = document.getElementById('categoryChart');
    if (ctx2) {
      Chart.getChart(ctx2)?.destroy();
      const cats = {};
      trends.forEach(t => { cats[t.category] = (cats[t.category] || 0) + 1; });
      const catLabels = Object.keys(cats);
      const catData   = Object.values(cats);
      const catColors = ['#00ff88','#3b82f6','#f5c400','#a855f7','#ff2244','#f97316','#06b6d4','#84cc16'];
      new Chart(ctx2, {
        type: 'doughnut',
        data: { labels: catLabels, datasets: [{ data: catData, backgroundColor: catColors, borderWidth: 0 }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: {
            legend: { position:'right', labels:{ color:'#6a7fa8', font:{family:'Rajdhani',size:12}, padding:10, boxWidth:12 } }
          }
        }
      });
    }
  }

  // ── Trends Page ───────────────────────────────────────────────
  async function loadTrends(forceRefresh = false) {
    const grid = document.getElementById('trendsGrid');
    if (!grid) return;
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted);font-family:var(--font-mono)">LOADING TRENDS...</div>';

    let trends = [];
    if (API && window.__backendReady) {
      const cat = document.querySelector('.filter-btn.active')?.dataset.cat || 'all';
      trends = await API.getTrends({ region: currentRegion, category: cat, forceRefresh }).catch(() => []);
    }
    if (!trends.length) trends = getMockTrends();

    trendsData = trends;
    trendPage = 1;
    renderTrendsGrid(trends);
    bindCategoryFilter();
  }

  function renderTrendsGrid(trends) {
    const grid  = document.getElementById('trendsGrid');
    const start = (trendPage - 1) * TRENDS_PER_PAGE;
    const page  = trends.slice(start, start + TRENDS_PER_PAGE);

    if (!page.length) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted)">No trends found.</div>';
      return;
    }

    grid.innerHTML = page.map(t => `
      <div class="trend-card">
        <div class="trend-card-header">
          <div class="trend-emoji">${getCatEmoji(t.category)}</div>
          <div class="trend-card-meta">
            <div class="trend-card-name">${t.name}</div>
            <div class="trend-card-cat">${t.category}</div>
          </div>
        </div>
        <div class="trend-card-stats">
          <span class="trend-vol-badge">${t.volume || '–'}</span>
          <span class="trend-change-badge ${t.change_type || 'rising'}">${t.change_pct || '+100%'}</span>
        </div>
        <div class="trend-score-bar"><div class="trend-score-fill" style="width:${t.score||50}%"></div></div>
        <button class="btn-make-short" onclick="App.quickGenerate('${(t.name||'').replace(/'/g,"\\'")}','${t.category||'general'}')">
          <i class="fas fa-magic"></i> ⚡ Make Short
        </button>
      </div>
    `).join('');

    renderPagination('trendsPagination', trends.length, trendPage, TRENDS_PER_PAGE, (p) => {
      trendPage = p;
      renderTrendsGrid(trendsData);
    });
  }

  function bindCategoryFilter() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.dataset.cat;
        const filtered = cat === 'all' ? trendsData : trendsData.filter(t => t.category === cat);
        trendPage = 1;
        renderTrendsGrid(filtered);
      });
    });
  }

  function filterTrends(query) {
    const filtered = trendsData.filter(t => t.name.toLowerCase().includes(query));
    renderTrendsGrid(filtered);
  }

  // ── Generator ─────────────────────────────────────────────────
  function bindGenerator() {
    // Duration slider label
    const slider = document.getElementById('genDuration');
    const label  = document.getElementById('durationLabel');
    if (slider) {
      slider.addEventListener('input', () => { label.textContent = slider.value + 's'; });
    }

    // Style buttons
    document.querySelectorAll('.style-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.style-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    // Generate button
    document.getElementById('btnGenerate')?.addEventListener('click', runGenerate);

    // Schedule toggle
    document.getElementById('toggleSchedule')?.addEventListener('change', (e) => {
      document.getElementById('schedulePicker')?.classList.toggle('hidden', !e.target.checked);
    });

    // Connect from generator
    document.getElementById('btnConnectFromGen')?.addEventListener('click', openYTModal);

    // Copy buttons
    document.getElementById('btnCopyScript')?.addEventListener('click', () => {
      const script = currentShort?.script?.map(s => `[${s.action}] ${s.text}`).join('\n') || '';
      copyToClipboard(script, 'Script copied!');
    });
    document.getElementById('btnCopyHashtags')?.addEventListener('click', () => {
      const tags = currentShort?.hashtags?.join(' ') || '';
      copyToClipboard(tags, 'Hashtags copied!');
    });
    document.getElementById('btnCopyPrompt')?.addEventListener('click', () => {
      const prompt = buildInVideoPrompt(currentShort);
      copyToClipboard(prompt, 'InVideo prompt copied!');
    });
    document.getElementById('btnOpenInVideo')?.addEventListener('click', () => {
      const prompt = buildInVideoPrompt(currentShort);
      // Copy to clipboard and open InVideo AI
      navigator.clipboard.writeText(prompt).catch(() => {});
      window.open('https://www.invideoai.org/', '_blank');
      showToast('Prompt copied! Paste it in InVideo AI.');
    });

    // Post / save
    document.getElementById('btnSaveDraft')?.addEventListener('click', saveAsDraft);
    document.getElementById('btnPostNow')?.addEventListener('click', postNow);
  }

  async function runGenerate() {
    const topic = document.getElementById('genTopic')?.value?.trim();
    if (!topic) { showToast('Please enter a topic!'); return; }

    const btn = document.getElementById('btnGenerate');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner" style="width:20px;height:20px;border-width:2px"></span> GENERATING...';

    showGenLoading();

    try {
      let result;
      if (API && window.__backendReady) {
        result = await API.generateShort({
          topic,
          category: document.getElementById('genCategory')?.value,
          tone:     document.getElementById('genTone')?.value,
          duration: parseInt(document.getElementById('genDuration')?.value) || 30,
          style:    document.querySelector('.style-btn.active')?.dataset.style || 'Talking Head',
          audience: document.getElementById('genAudience')?.value || '',
          keywords: (document.getElementById('genKeywords')?.value || '').split(',').map(k => k.trim()).filter(Boolean),
        });
      } else {
        result = generateMockShort(topic);
      }

      currentShort = result;
      renderGeneratorResult(result);
    } catch (e) {
      showToast('Generation failed: ' + e.message);
      showGenPlaceholder();
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-magic"></i> Generate Short';
    }
  }

  function showGenLoading() {
    document.getElementById('genPlaceholder')?.classList.add('hidden');
    document.getElementById('genResult')?.classList.add('hidden');
    const output = document.getElementById('genOutput');
    const existing = output?.querySelector('.gen-loading');
    if (!existing) {
      const el = document.createElement('div');
      el.className = 'gen-loading';
      el.innerHTML = '<div class="spinner"></div><p>GENERATING YOUR SHORT...</p>';
      output?.appendChild(el);
    }
  }

  function showGenPlaceholder() {
    document.getElementById('genPlaceholder')?.classList.remove('hidden');
    document.getElementById('genResult')?.classList.add('hidden');
    document.querySelector('.gen-loading')?.remove();
  }

  function renderGeneratorResult(short) {
    document.querySelector('.gen-loading')?.remove();
    document.getElementById('genPlaceholder')?.classList.add('hidden');
    const result = document.getElementById('genResult');
    result?.classList.remove('hidden');

    document.getElementById('resultTitle').textContent = short.title || 'Untitled';
    document.getElementById('resultCategory').textContent = short.category || '';
    document.getElementById('resultDuration').textContent = short.duration || '30s';
    document.getElementById('resultStyle').textContent = short.style || '';

    // Virality ring animation
    const score = short.score || 0;
    document.getElementById('viralityScore').textContent = score;
    const arc = document.getElementById('viralityArc');
    if (arc) {
      const circumference = 2 * Math.PI * 15.91;
      setTimeout(() => {
        arc.style.strokeDasharray = `${(score / 100) * circumference} ${circumference}`;
        arc.style.transition = 'stroke-dasharray 1s ease';
      }, 100);
    }

    // Script
    const scriptList = document.getElementById('scriptList');
    if (scriptList && short.script) {
      scriptList.innerHTML = short.script.map(s => `
        <div class="script-item">
          <span class="script-time">${s.time}</span>
          <span class="script-action">${s.action}</span>
          <span class="script-text">${s.text}</span>
        </div>
      `).join('');
    }

    // Storyboard (9:16)
    const sbGrid = document.getElementById('storyboardGrid');
    if (sbGrid && short.storyboard) {
      sbGrid.innerHTML = short.storyboard.map(s => `
        <div class="storyboard-card">
          <span class="storyboard-num">${s.num}</span>
          <span class="storyboard-time">${s.timeStart}</span>
          <div class="storyboard-emoji">${s.emoji}</div>
          <div class="storyboard-desc">${s.desc}</div>
          <span class="aspect-label">9:16</span>
        </div>
      `).join('');
    }

    // Hashtags
    const cloud = document.getElementById('hashtagsCloud');
    if (cloud && short.hashtags) {
      cloud.innerHTML = short.hashtags.map(h => `<span class="hashtag-pill">${h}</span>`).join('');
    }

    // InVideo prompt
    const prompt = buildInVideoPrompt(short);
    const preview = document.getElementById('invideoPromptPreview');
    if (preview) preview.textContent = prompt;

    // Post panel — channel info
    if (ytConnected && ytChannel) {
      document.getElementById('noChannelMsg')?.classList.add('hidden');
      document.getElementById('channelReadyMsg')?.classList.remove('hidden');
      document.getElementById('postChannelName').textContent = ytChannel.name || '';
      document.getElementById('postChannelSubs').textContent = ytChannel.subscribers || '';
      if (ytChannel.avatar_url) document.getElementById('postChannelAvatar').src = ytChannel.avatar_url;
    } else {
      document.getElementById('noChannelMsg')?.classList.remove('hidden');
      document.getElementById('channelReadyMsg')?.classList.add('hidden');
    }
  }

  function buildInVideoPrompt(short) {
    if (!short) return '';
    const script = (short.script || []).map(s => `[${s.action} @ ${s.time}] ${s.text}`).join('\n');
    const tags   = (short.hashtags || []).join(' ');
    return [
      `Create a YouTube Short video in 9:16 portrait aspect ratio (1080x1920px).`,
      ``,
      `Title: ${short.title || ''}`,
      `Duration: ${short.duration || '30s'}`,
      `Style: ${short.style || 'Talking Head'}`,
      `Tone: ${short.tone || 'educational'}`,
      ``,
      `SCRIPT:`,
      script,
      ``,
      `HASHTAGS: ${tags}`,
      ``,
      `IMPORTANT: Use 9:16 vertical format. Optimise for YouTube Shorts mobile viewing.`,
    ].join('\n');
  }

  async function saveAsDraft() {
    if (!currentShort?.id) return showToast('Generate a Short first.');
    if (API && window.__backendReady) {
      await API.updateShort(currentShort.id, { status: 'draft' }).catch(() => {});
    }
    showToast('Saved as draft!');
  }

  async function postNow() {
    if (!currentShort?.id) return showToast('Generate a Short first.');
    if (!ytConnected) return showToast('Connect YouTube first.');

    const scheduled = document.getElementById('toggleSchedule')?.checked;
    const schedTime = document.getElementById('scheduleTime')?.value;

    if (scheduled && schedTime) {
      if (API && window.__backendReady) {
        await API.scheduleShort(currentShort.id, schedTime).catch(e => showToast('Schedule failed: ' + e.message));
        showToast('Short scheduled!');
      }
    } else {
      showToast('Upload your MP4 first via the API, then post will trigger automatically.');
    }
  }

  // ── Library ───────────────────────────────────────────────────
  function bindLibrary() {
    document.getElementById('libSearch')?.addEventListener('input', (e) => {
      loadLibrary({ search: e.target.value });
    });
    document.getElementById('libStatusFilter')?.addEventListener('change', () => loadLibrary());
    document.getElementById('libCatFilter')?.addEventListener('change', () => loadLibrary());
  }

  async function loadLibrary(overrides = {}) {
    const grid = document.getElementById('shortsGrid');
    if (!grid) return;

    const status   = overrides.status   || document.getElementById('libStatusFilter')?.value || 'all';
    const category = overrides.category || document.getElementById('libCatFilter')?.value    || 'all';
    const search   = overrides.search !== undefined ? overrides.search : (document.getElementById('libSearch')?.value || '');

    let shorts = [];
    if (API && window.__backendReady) {
      const res = await API.getShorts({ status, category, search }).catch(() => ({ shorts: [] }));
      shorts = res.shorts || [];
    }

    if (!shorts.length) {
      grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--text-muted);font-family:var(--font-mono)">NO SHORTS FOUND.<br><br><small>Generate your first Short in the Generator tab.</small></div>';
      return;
    }

    grid.innerHTML = shorts.map(s => `
      <div class="short-card">
        <div class="short-thumb">${getCatEmoji(s.category)}</div>
        <div class="short-info">
          <div class="short-title">${s.title}</div>
          <div class="short-footer">
            <span class="short-cat">${s.category}</span>
            <span class="status-pill ${s.status}">${s.status}</span>
          </div>
        </div>
      </div>
    `).join('');
  }

  // ── Analytics ──────────────────────────────────────────────────
  async function loadAnalytics() {
    if (API && window.__backendReady) {
      const data = await API.getYouTubeAnalytics().catch(() => null);
      if (data && data.totals) {
        document.getElementById('aViews').textContent    = formatNum(data.totals.views);
        document.getElementById('aLikes').textContent    = formatNum(data.totals.likes);
        document.getElementById('aComments').textContent = formatNum(data.totals.comments);
        document.getElementById('aSubs').textContent     = ytChannel?.subscribers || '–';
        renderTopShorts(data.videos || []);
      }

      const dash = await API.getDashboardAnalytics().catch(() => null);
      if (dash) renderAnalyticsChart(dash);
    } else {
      ['aViews','aLikes','aComments','aSubs'].forEach(id => {
        document.getElementById(id).textContent = '–';
      });
    }
  }

  function renderTopShorts(videos) {
    const list = document.getElementById('topShortsList');
    if (!list) return;
    if (!videos.length) {
      list.innerHTML = '<div style="color:var(--text-muted);font-size:13px;padding:20px;text-align:center">No posted Shorts yet.</div>';
      return;
    }
    list.innerHTML = videos.slice(0, 8).map((v, i) => `
      <div class="top-short-row">
        <span class="ts-rank">#${i+1}</span>
        <span class="ts-title">${v.title || 'Untitled'}</span>
        <span class="ts-views">${formatNum(v.views)} views</span>
      </div>
    `).join('');
  }

  function renderAnalyticsChart(dash) {
    const ctx = document.getElementById('analyticsChart');
    if (!ctx || typeof Chart === 'undefined') return;
    Chart.getChart(ctx)?.destroy();
    const daily = dash.dailyShorts || [];
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: daily.map(d => d.day),
        datasets: [{ label: 'Shorts Created', data: daily.map(d => d.count), backgroundColor: 'rgba(0,255,136,0.3)', borderColor: '#00ff88', borderWidth: 1 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color:'rgba(255,255,255,0.04)' }, ticks: { color:'#6a7fa8' } },
          y: { grid: { color:'rgba(255,255,255,0.04)' }, ticks: { color:'#6a7fa8' } },
        }
      }
    });
  }

  // ── Settings ──────────────────────────────────────────────────
  function loadSettingsPage() {
    if (ytConnected && ytChannel) {
      document.getElementById('ytDisconnectedSettings')?.classList.add('hidden');
      document.getElementById('ytConnectedSettings')?.classList.remove('hidden');
      if (ytChannel.avatar_url) document.getElementById('settingsAvatar').src = ytChannel.avatar_url;
      document.getElementById('settingsChannelName').textContent = ytChannel.name || '';
      document.getElementById('settingsChannelHandle').textContent = ytChannel.handle || '';
      document.getElementById('settingsChannelSubs').textContent = ytChannel.subscribers ? ytChannel.subscribers + ' subscribers' : '';
    } else {
      document.getElementById('ytDisconnectedSettings')?.classList.remove('hidden');
      document.getElementById('ytConnectedSettings')?.classList.add('hidden');
    }
  }

  function bindSettings() {
    document.getElementById('btnConnectYT')?.addEventListener('click', openYTModal);
    document.getElementById('btnDisconnect')?.addEventListener('click', disconnectYT);
    document.getElementById('btnRefreshChannel')?.addEventListener('click', async () => {
      if (Auth && window.__backendReady) {
        await Auth.refreshChannel().catch(() => {});
        await checkYouTubeStatus();
        loadSettingsPage();
        showToast('Channel refreshed!');
      }
    });
    document.getElementById('btnTriggerAutopilot')?.addEventListener('click', async () => {
      if (API && window.__backendReady) {
        await API.triggerAutopilot().catch(() => {});
        showToast('Autopilot cycle triggered!');
      } else {
        showToast('Backend not connected.');
      }
    });
    document.getElementById('autopilotEnabled')?.addEventListener('change', async (e) => {
      if (API && window.__backendReady) {
        await API.updateSettings({ autopilot_enabled: e.target.checked ? 'true' : 'false' }).catch(() => {});
      }
    });
  }

  // ── YouTube Auth ───────────────────────────────────────────────
  async function checkYouTubeStatus() {
    if (!Auth || !window.__backendReady) return;
    try {
      const status = await Auth.getYouTubeStatus();
      ytConnected = status.connected;
      ytChannel   = status.channel || null;
      updateChannelUI();
    } catch {}
  }

  function updateChannelUI() {
    const disc = document.getElementById('channelDisconnected');
    const conn = document.getElementById('channelConnected');
    if (ytConnected && ytChannel) {
      disc?.classList.add('hidden');
      conn?.classList.remove('hidden');
      document.getElementById('channelName').textContent = ytChannel.name || '';
      document.getElementById('channelSubs').textContent = (ytChannel.subscribers || '') + ' subscribers';
      if (ytChannel.avatar_url) document.getElementById('channelAvatar').src = ytChannel.avatar_url;
    } else {
      disc?.classList.remove('hidden');
      conn?.classList.add('hidden');
    }
  }

  function openYTModal() {
    if (Auth && window.__backendReady) {
      // Real OAuth flow
      Auth.getYouTubeAuthUrl().then(url => {
        window.location.href = url;
      }).catch(() => showMockModal());
    } else {
      showMockModal();
    }
  }

  function showMockModal() {
    document.getElementById('ytModal')?.classList.remove('hidden');
    document.getElementById('modalStep1')?.classList.remove('hidden');
    document.getElementById('modalStep2')?.classList.add('hidden');
    document.getElementById('modalStep3')?.classList.add('hidden');
  }

  async function disconnectYT() {
    if (Auth && window.__backendReady) {
      await Auth.disconnectYouTube().catch(() => {});
    }
    ytConnected = false;
    ytChannel   = null;
    updateChannelUI();
    loadSettingsPage();
    showToast('YouTube channel disconnected.');
  }

  // ── Modal bindings ─────────────────────────────────────────────
  function bindModal() {
    document.getElementById('modalClose')?.addEventListener('click', () => document.getElementById('ytModal')?.classList.add('hidden'));
    document.getElementById('btnConnectSidebar')?.addEventListener('click', openYTModal);

    // Mock OAuth steps
    document.getElementById('btnGoogleAuth')?.addEventListener('click', () => {
      if (!window.__backendReady) {
        document.getElementById('modalStep1')?.classList.add('hidden');
        document.getElementById('modalStep2')?.classList.remove('hidden');
        document.getElementById('ms1')?.classList.remove('active');
        document.getElementById('ms2')?.classList.add('active');
        const mockChannels = [
          { id:'UC1', name:'TechVibes Daily', handle:'@techvibesdaily', subs:'48.2K', avatar:'https://ui-avatars.com/api/?name=TechVibes&background=ff2244&color=fff&size=40' },
          { id:'UC2', name:'TrendWatcher', handle:'@trendwatcher', subs:'12.8K', avatar:'https://ui-avatars.com/api/?name=TrendW&background=00ff88&color=000&size=40' },
        ];
        document.getElementById('modalChannelList').innerHTML = mockChannels.map(c => `
          <div class="modal-channel-item" onclick="App.selectMockChannel('${c.id}','${c.name}','${c.handle}','${c.subs}','${c.avatar}')">
            <img src="${c.avatar}" alt="${c.name}"/>
            <div><div class="mc-name">${c.name}</div><div class="mc-subs">${c.subs} subscribers</div></div>
          </div>
        `).join('');
      }
    });
    document.getElementById('btnModalDone')?.addEventListener('click', () => {
      document.getElementById('ytModal')?.classList.add('hidden');
      updateChannelUI();
    });
  }

  function selectMockChannel(id, name, handle, subs, avatar) {
    ytConnected = true;
    ytChannel   = { id, name, handle, subscribers: subs, avatar_url: avatar };
    document.getElementById('modalStep2')?.classList.add('hidden');
    document.getElementById('modalStep3')?.classList.remove('hidden');
    document.getElementById('ms2')?.classList.remove('active');
    document.getElementById('ms3')?.classList.add('active');
    document.getElementById('connectedMsg').textContent = `${name} has been successfully connected.`;
    updateChannelUI();
    loadSettingsPage();
  }

  // ── Utilities ─────────────────────────────────────────────────
  function quickGenerate(topic, category) {
    navigateTo('generator');
    const topicInput = document.getElementById('genTopic');
    const catSelect  = document.getElementById('genCategory');
    if (topicInput) topicInput.value = topic;
    if (catSelect)  catSelect.value  = category;
    setTimeout(() => document.getElementById('btnGenerate')?.click(), 300);
  }

  function renderPagination(containerId, total, currentPage, perPage, onPage) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const pages = Math.ceil(total / perPage);
    if (pages <= 1) { container.innerHTML = ''; return; }
    container.innerHTML = Array.from({length: pages}, (_, i) => i + 1).map(p => `
      <button class="page-btn ${p === currentPage ? 'active' : ''}" onclick="(${onPage})(${p})">${p}</button>
    `).join('');
  }

  function showToast(msg) {
    const toast = document.getElementById('successToast');
    const span  = document.getElementById('toastMessage');
    if (!toast || !span) return;
    span.textContent = msg;
    toast.classList.remove('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.add('hidden'), 3000);
  }

  function copyToClipboard(text, successMsg) {
    navigator.clipboard.writeText(text).then(() => showToast(successMsg)).catch(() => showToast('Copy failed'));
  }

  function formatNum(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(n || 0);
  }

  function getCatEmoji(cat) {
    return { technology:'🤖', entertainment:'🎬', sports:'⚽', science:'🔬', health:'💪', business:'📈', gaming:'🎮', food:'🍔', travel:'✈️', fashion:'👗', general:'🔥' }[cat] || '🔥';
  }

  // ── Mock data ──────────────────────────────────────────────────
  function getMockTrends() {
    return [
      { id:1, name:'AI Agents Going Mainstream', category:'technology', volume:'2.4M', change_pct:'+340%', change_type:'hot', score:96, sparkline:[20,35,45,60,75,88,96] },
      { id:2, name:'GPT-5 Release Rumours', category:'technology', volume:'1.8M', change_pct:'+210%', change_type:'hot', score:91, sparkline:[10,25,40,55,70,85,91] },
      { id:3, name:'Squid Game Season 3', category:'entertainment', volume:'3.1M', change_pct:'+480%', change_type:'hot', score:98, sparkline:[15,30,50,70,85,95,98] },
      { id:4, name:'Champions League Final', category:'sports', volume:'2.9M', change_pct:'+290%', change_type:'hot', score:95, sparkline:[30,45,55,70,80,90,95] },
      { id:5, name:'James Webb Discovery', category:'science', volume:'890K', change_pct:'+150%', change_type:'rising', score:79, sparkline:[20,30,40,55,65,72,79] },
      { id:6, name:'Ozempic Weight Loss', category:'health', volume:'1.2M', change_pct:'+180%', change_type:'rising', score:85, sparkline:[25,38,50,62,72,80,85] },
      { id:7, name:'Bitcoin ETF New Highs', category:'business', volume:'1.5M', change_pct:'+220%', change_type:'hot', score:88, sparkline:[22,34,48,60,72,82,88] },
      { id:8, name:'GTA VI Release Date', category:'gaming', volume:'4.2M', change_pct:'+600%', change_type:'hot', score:99, sparkline:[40,55,68,80,90,96,99] },
      { id:9, name:'Taylor Swift New Album', category:'entertainment', volume:'2.6M', change_pct:'+350%', change_type:'hot', score:94, sparkline:[20,40,58,72,83,90,94] },
      { id:10, name:'Quantum Computing Breakthrough', category:'science', volume:'650K', change_pct:'+120%', change_type:'rising', score:73, sparkline:[15,25,35,48,58,67,73] },
    ];
  }

  function generateMockShort(topic) {
    return {
      id: 'mock_' + Date.now(),
      title: `🔥 ${topic}: The Truth Nobody Tells You`,
      description: `Everything you need to know about ${topic}.`,
      category: 'general',
      tone: 'educational',
      duration: '30s',
      style: 'Talking Head',
      score: 78,
      script: [
        { time:'0:00', action:'HOOK',       text:`Wait — everything you think about ${topic} is wrong. Here's what's really happening.` },
        { time:'0:05', action:'CONTEXT',    text:`${topic} has been everywhere lately. Millions are searching for this right now.` },
        { time:'0:12', action:'MAIN_POINT', text:`Here's the key thing most people miss about ${topic}.` },
        { time:'0:22', action:'EXAMPLE',    text:`Real-world examples are already showing massive impact.` },
        { time:'0:32', action:'CTA',        text:`If this blew your mind, follow for more insights like this every day. 👆` },
      ],
      storyboard: [
        { num:1, emoji:'🎬', desc:'Camera close-up, direct eye contact with viewer', timeStart:'0:00' },
        { num:2, emoji:'📊', desc:'Text overlay with key stats and trend data', timeStart:'0:05' },
        { num:3, emoji:'💡', desc:'Visual explanation with dynamic graphics', timeStart:'0:12' },
        { num:4, emoji:'🌍', desc:'Real-world footage and examples', timeStart:'0:22' },
        { num:5, emoji:'👆', desc:'CTA overlay with subscribe animation', timeStart:'0:32' },
      ],
      hashtags: [`#${topic.replace(/\s+/g,'')}`, '#trending', '#shorts', '#viral', '#fyp', '#youtube', '#learn', '#today'],
    };
  }

  // Expose public interface
  return { init, quickGenerate, selectMockChannel, navigateTo };
})();
