// ============================================================
//  routes/analytics.js
// ============================================================
const express  = require('express');
const router   = express.Router();
const db       = require('../utils/database');
const youtube  = require('../services/youtubeService');

// GET /api/analytics/dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const totalShorts  = db.get("SELECT COUNT(*) as n FROM shorts")?.n || 0;
    const posted       = db.get("SELECT COUNT(*) as n FROM shorts WHERE status = 'posted'")?.n || 0;
    const activeTrends = db.get("SELECT COUNT(*) as n FROM trends WHERE fetched_at > ?",
                                [Math.floor(Date.now()/1000) - 7200])?.n || 0;

    // Shorts created per day for the last 7 days
    const sevenDaysAgo = Math.floor(Date.now()/1000) - 7 * 86400;
    const dailyShorts  = db.all(`
      SELECT date(created_at, 'unixepoch') as day, COUNT(*) as count
      FROM shorts WHERE created_at > ?
      GROUP BY day ORDER BY day ASC
    `, [sevenDaysAgo]);

    // Category distribution
    const byCategory = db.all(`
      SELECT category, COUNT(*) as count FROM shorts GROUP BY category ORDER BY count DESC
    `);

    // Latest scheduler log
    const recentLogs = db.all(`
      SELECT * FROM scheduler_log ORDER BY ran_at DESC LIMIT 20
    `);

    res.json({
      success: true,
      summary: { totalShorts, posted, activeTrends },
      dailyShorts,
      byCategory,
      recentLogs,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/analytics/youtube  — pull live stats from YouTube for posted Shorts
router.get('/youtube', async (req, res) => {
  const stored = youtube.getStoredChannel();
  if (!stored) return res.json({ connected: false, videos: [] });

  try {
    const postedShorts = db.all(
      "SELECT id, title, youtube_id FROM shorts WHERE status = 'posted' AND youtube_id IS NOT NULL LIMIT 20"
    );

    const stats = [];
    for (const s of postedShorts) {
      try {
        const videoStats = await youtube.getVideoAnalytics(stored.tokens, s.youtube_id);
        if (videoStats) stats.push({ ...videoStats, shortId: s.id });
      } catch {}
    }

    const totals = stats.reduce((acc, v) => ({
      views:    acc.views    + v.views,
      likes:    acc.likes    + v.likes,
      comments: acc.comments + v.comments,
    }), { views: 0, likes: 0, comments: 0 });

    res.json({ connected: true, totals, videos: stats });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/analytics/scheduler  — scheduler health
router.get('/scheduler', (req, res) => {
  const logs = db.all('SELECT * FROM scheduler_log ORDER BY ran_at DESC LIMIT 50');
  const errors   = logs.filter(l => l.status === 'error').length;
  const successes = logs.filter(l => l.status === 'success').length;
  res.json({ success: true, errors, successes, logs });
});

module.exports = router;
