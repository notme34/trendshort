// ============================================================
//  TrendShorts Backend — server.js
// ============================================================
require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const helmet    = require('helmet');
const session   = require('express-session');
const rateLimit = require('express-rate-limit');
const path      = require('path');
const fs        = require('fs');

const logger    = require('./utils/logger');
const db        = require('./utils/database');
const scheduler = require('./services/scheduler');

const authRoutes      = require('./routes/auth');
const trendsRoutes    = require('./routes/trends');
const generatorRoutes = require('./routes/generator');
const youtubeRoutes   = require('./routes/youtube');
const shortsRoutes    = require('./routes/shorts');
const analyticsRoutes = require('./routes/analytics');
const settingsRoutes  = require('./routes/settings');

const app  = express();
const PORT = process.env.PORT || 3001;

// Ensure data directories exist
['./data', './data/videos', './data/logs'].forEach(d => {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
}));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300 }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

const SQLiteStore = require('connect-sqlite3')(session);
app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: './data' }),
  secret: process.env.SESSION_SECRET || 'dev-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000,
  },
}));

app.use('/api/auth',      authRoutes);
app.use('/api/trends',    trendsRoutes);
app.use('/api/generator', generatorRoutes);
app.use('/api/youtube',   youtubeRoutes);
app.use('/api/shorts',    shortsRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/settings',  settingsRoutes);

// InVideo AI proxy info endpoint
app.get('/api/invideo/info', (req, res) => {
  res.json({
    url:          process.env.INVIDEO_URL || 'https://www.invideoai.org/',
    aspect_ratio: '9:16',
    platform:     'YouTube Shorts',
    instructions: [
      'Open InVideo AI',
      'Paste the generated prompt into the AI prompt box',
      'Select 9:16 (Vertical / Shorts) aspect ratio',
      'Generate, customise, and export your video as MP4',
      'Return to TrendShorts and upload your MP4 to post',
    ],
  });
});

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '2.0.0',
    time: new Date().toISOString(),
    db: db.isReady() ? 'connected' : 'error',
    invideo_url: process.env.INVIDEO_URL || 'https://www.invideoai.org/',
    youtube_connected: !!(db.isReady() && db.get('SELECT id FROM youtube_channels LIMIT 1')),
  });
});

app.use((err, req, res, _next) => {
  logger.error(`${err.message}`, { stack: err.stack });
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

async function start() {
  await db.init();
  scheduler.start();
  app.listen(PORT, () => {
    logger.info(`TrendShorts backend running on http://localhost:${PORT}`);
  });
}

start().catch(err => { logger.error('Startup failed:', err); process.exit(1); });
