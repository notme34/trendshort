// ============================================================
//  routes/trends.js
// ============================================================
const express  = require('express');
const router   = express.Router();
const trends   = require('../services/trendsService');
const scheduler = require('../services/scheduler');
const db       = require('../utils/database');

// GET /api/trends?region=US&category=all&forceRefresh=false
router.get('/', async (req, res) => {
  try {
    const { region = 'US', category = 'all', forceRefresh = 'false' } = req.query;
    const data = await trends.getTrends({
      region,
      category,
      forceRefresh: forceRefresh === 'true',
    });
    res.json({ success: true, count: data.length, trends: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/trends/search?q=bitcoin&region=US
router.get('/search', async (req, res) => {
  const { q, region = 'US' } = req.query;
  if (!q) return res.status(400).json({ error: 'Query param "q" is required' });
  try {
    const data = await trends.searchTrends(q, region);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/trends/:id
router.get('/:id', (req, res) => {
  const row = db.get('SELECT * FROM trends WHERE id = ?', [req.params.id]);
  if (!row) return res.status(404).json({ error: 'Trend not found' });
  res.json({
    ...row,
    tags:      safeJsonParse(row.tags, []),
    sparkline: safeJsonParse(row.sparkline, []),
  });
});

// POST /api/trends/refresh  — manual refresh trigger
router.post('/refresh', async (req, res) => {
  try {
    await scheduler.triggerTrendsRefresh();
    res.json({ success: true, message: 'Trends refresh triggered' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function safeJsonParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

module.exports = router;
