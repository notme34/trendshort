// ============================================================
//  utils/database.js — SQLite via better-sqlite3
// ============================================================
const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');
const logger   = require('./logger');

const DB_PATH = process.env.DB_PATH || './data/trendshorts.db';

let db = null;

function isReady() { return db !== null; }

async function init() {
  // Ensure the data directory exists
  const dir = path.dirname(path.resolve(DB_PATH));
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  db = new Database(path.resolve(DB_PATH));
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  createSchema();
  logger.info(`SQLite database ready at ${DB_PATH}`);
}

function createSchema() {
  db.exec(`
    -- Trends cache (refreshed every 2 hours from Google Trends / SerpAPI)
    CREATE TABLE IF NOT EXISTS trends (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT NOT NULL,
      category    TEXT NOT NULL DEFAULT 'general',
      volume      TEXT,
      volume_num  INTEGER DEFAULT 0,
      change_pct  TEXT,
      change_type TEXT DEFAULT 'rising',    -- hot | rising | stable
      score       INTEGER DEFAULT 50,
      description TEXT,
      tags        TEXT,                      -- JSON array string
      region      TEXT DEFAULT 'US',
      fetched_at  INTEGER NOT NULL,          -- Unix timestamp
      sparkline   TEXT                       -- JSON array of 7 numbers
    );

    -- Generated / saved Shorts
    CREATE TABLE IF NOT EXISTS shorts (
      id            TEXT PRIMARY KEY,        -- UUID
      title         TEXT NOT NULL,
      description   TEXT,
      category      TEXT,
      tone          TEXT,
      duration      TEXT,
      style         TEXT,
      score         INTEGER DEFAULT 0,
      script        TEXT,                    -- JSON
      storyboard    TEXT,                    -- JSON
      hashtags      TEXT,                    -- JSON
      status        TEXT DEFAULT 'draft',    -- draft | scheduled | posted | failed
      trend_id      INTEGER,
      youtube_id    TEXT,                    -- YouTube video ID after upload
      youtube_url   TEXT,
      scheduled_at  INTEGER,                 -- Unix timestamp (nullable)
      posted_at     INTEGER,
      created_at    INTEGER NOT NULL,
      FOREIGN KEY (trend_id) REFERENCES trends(id)
    );

    -- YouTube channel info (one row per connected account)
    CREATE TABLE IF NOT EXISTS youtube_channels (
      id            TEXT PRIMARY KEY,        -- YouTube channel ID
      name          TEXT,
      handle        TEXT,
      subscribers   TEXT,
      video_count   INTEGER DEFAULT 0,
      avatar_url    TEXT,
      access_token  TEXT NOT NULL,
      refresh_token TEXT NOT NULL,
      token_expiry  INTEGER,                 -- Unix timestamp
      connected_at  INTEGER NOT NULL
    );

    -- App settings key/value store
    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    -- Scheduler log
    CREATE TABLE IF NOT EXISTS scheduler_log (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      job        TEXT NOT NULL,
      status     TEXT NOT NULL,             -- success | error
      message    TEXT,
      ran_at     INTEGER NOT NULL
    );
  `);
}

// ── Generic helpers ───────────────────────────────────────────

function get(sql, params = []) {
  return db.prepare(sql).get(...params);
}

function all(sql, params = []) {
  return db.prepare(sql).all(...params);
}

function run(sql, params = []) {
  return db.prepare(sql).run(...params);
}

function transaction(fn) {
  return db.transaction(fn)();
}

module.exports = { init, isReady, get, all, run, transaction };
