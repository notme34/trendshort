// ============================================================
//  services/youtubeService.js
//  Handles YouTube OAuth 2.0 and video upload via Data API v3
// ============================================================
const { google }  = require('googleapis');
const fs          = require('fs');
const path        = require('path');
const db          = require('../utils/database');
const logger      = require('../utils/logger');

const youtube = google.youtube('v3');

// ── OAuth2 client factory ─────────────────────────────────────

function createOAuthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI || 'http://localhost:3001/api/auth/youtube/callback'
  );
}

// ── Auth URL ──────────────────────────────────────────────────

function getAuthUrl() {
  const client = createOAuthClient();
  return client.generateAuthUrl({
    access_type: 'offline',
    prompt:      'consent',          // Force refresh_token to be returned
    scope: [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube.readonly',
      'https://www.googleapis.com/auth/userinfo.profile',
    ],
  });
}

// ── Exchange code for tokens ──────────────────────────────────

async function exchangeCode(code) {
  const client = createOAuthClient();
  const { tokens } = await client.getToken(code);
  return tokens;
}

// ── Get authenticated client from stored tokens ───────────────

async function getAuthenticatedClient(tokens) {
  const client = createOAuthClient();
  client.setCredentials(tokens);

  // Auto-refresh token if expired
  client.on('tokens', (newTokens) => {
    if (newTokens.refresh_token) {
      logger.info('YouTube token refreshed');
      updateStoredTokens({ ...tokens, ...newTokens });
    }
  });

  return client;
}

// ── Fetch channel info ────────────────────────────────────────

async function getChannelInfo(tokens) {
  const auth = await getAuthenticatedClient(tokens);

  const res = await youtube.channels.list({
    auth,
    part: 'snippet,statistics',
    mine: true,
  });

  const channel = res.data.items?.[0];
  if (!channel) throw new Error('No YouTube channel found for this account');

  return {
    id:          channel.id,
    name:        channel.snippet.title,
    handle:      channel.snippet.customUrl || `@${channel.snippet.title.toLowerCase().replace(/\s+/g, '')}`,
    subscribers: formatCount(channel.statistics.subscriberCount),
    video_count: parseInt(channel.statistics.videoCount) || 0,
    avatar_url:  channel.snippet.thumbnails?.default?.url || '',
  };
}

// ── Upload a Short ────────────────────────────────────────────

/**
 * Uploads an MP4 file to YouTube as a Short.
 * @param {Object} opts
 * @param {string} opts.videoFilePath  - Absolute path to the MP4 file
 * @param {string} opts.title          - Video title (max 100 chars)
 * @param {string} opts.description    - Video description
 * @param {string[]} opts.hashtags     - Array of hashtag strings
 * @param {boolean} opts.notifySubscribers
 * @param {boolean} opts.madeForKids
 * @param {Object} opts.tokens         - OAuth tokens
 */
async function uploadShort(opts) {
  const {
    videoFilePath,
    title,
    description = '',
    hashtags    = [],
    notifySubscribers = true,
    madeForKids       = false,
    tokens,
  } = opts;

  if (!fs.existsSync(videoFilePath)) {
    throw new Error(`Video file not found: ${videoFilePath}`);
  }

  const auth = await getAuthenticatedClient(tokens);

  // Build description with hashtags appended
  const hashtagBlock = hashtags.slice(0, 15).join(' ');
  const fullDesc     = `${description}\n\n${hashtagBlock}`.trim();

  const fileSize = fs.statSync(videoFilePath).size;
  logger.info(`Uploading Short: "${title}" (${(fileSize / 1024 / 1024).toFixed(1)} MB)`);

  const response = await youtube.videos.insert({
    auth,
    part: 'snippet,status',
    notifySubscribers,
    requestBody: {
      snippet: {
        title:       title.slice(0, 100),
        description: fullDesc.slice(0, 5000),
        tags:        hashtags.map(h => h.replace('#', '')).slice(0, 30),
        categoryId:  '22', // People & Blogs (default for Shorts)
      },
      status: {
        privacyStatus:  'public',
        selfDeclaredMadeForKids: madeForKids,
      },
    },
    media: {
      mimeType: 'video/mp4',
      body:     fs.createReadStream(videoFilePath),
    },
  }, {
    // Progress tracking
    onUploadProgress: (evt) => {
      const pct = Math.round((evt.bytesRead / fileSize) * 100);
      logger.debug(`Upload progress: ${pct}%`);
    },
  });

  const videoId  = response.data.id;
  const videoUrl = `https://www.youtube.com/shorts/${videoId}`;
  logger.info(`Short uploaded successfully: ${videoUrl}`);

  return { videoId, videoUrl };
}

// ── List channel's uploaded videos ───────────────────────────

async function listUploads(tokens, maxResults = 20) {
  const auth = await getAuthenticatedClient(tokens);

  // Get uploads playlist ID
  const channelRes = await youtube.channels.list({
    auth,
    part: 'contentDetails',
    mine: true,
  });

  const uploadsId = channelRes.data.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  if (!uploadsId) return [];

  const listRes = await youtube.playlistItems.list({
    auth,
    part:       'snippet',
    playlistId: uploadsId,
    maxResults,
  });

  return (listRes.data.items || []).map(item => ({
    videoId:     item.snippet.resourceId.videoId,
    title:       item.snippet.title,
    description: item.snippet.description,
    thumbnail:   item.snippet.thumbnails?.medium?.url || '',
    publishedAt: item.snippet.publishedAt,
    url:         `https://www.youtube.com/shorts/${item.snippet.resourceId.videoId}`,
  }));
}

// ── Get video analytics ───────────────────────────────────────

async function getVideoAnalytics(tokens, videoId) {
  const auth = await getAuthenticatedClient(tokens);

  const res = await youtube.videos.list({
    auth,
    part: 'statistics,snippet',
    id:   videoId,
  });

  const v = res.data.items?.[0];
  if (!v) return null;

  return {
    videoId,
    title:     v.snippet.title,
    views:     parseInt(v.statistics.viewCount)    || 0,
    likes:     parseInt(v.statistics.likeCount)    || 0,
    comments:  parseInt(v.statistics.commentCount) || 0,
    published: v.snippet.publishedAt,
  };
}

// ── Persist & retrieve tokens ─────────────────────────────────

function saveChannelToDB(channelInfo, tokens) {
  db.run(`
    INSERT INTO youtube_channels
      (id, name, handle, subscribers, video_count, avatar_url,
       access_token, refresh_token, token_expiry, connected_at)
    VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET
      name=excluded.name, handle=excluded.handle, subscribers=excluded.subscribers,
      video_count=excluded.video_count, avatar_url=excluded.avatar_url,
      access_token=excluded.access_token, refresh_token=excluded.refresh_token,
      token_expiry=excluded.token_expiry
  `, [
    channelInfo.id, channelInfo.name, channelInfo.handle,
    channelInfo.subscribers, channelInfo.video_count, channelInfo.avatar_url,
    tokens.access_token, tokens.refresh_token,
    tokens.expiry_date ? Math.floor(tokens.expiry_date / 1000) : null,
    Math.floor(Date.now() / 1000),
  ]);
}

function getStoredChannel() {
  const row = db.get('SELECT * FROM youtube_channels LIMIT 1');
  if (!row) return null;
  return {
    channel: {
      id:          row.id,
      name:        row.name,
      handle:      row.handle,
      subscribers: row.subscribers,
      video_count: row.video_count,
      avatar_url:  row.avatar_url,
      connected_at: row.connected_at,
    },
    tokens: {
      access_token:  row.access_token,
      refresh_token: row.refresh_token,
      expiry_date:   row.token_expiry ? row.token_expiry * 1000 : null,
    },
  };
}

function updateStoredTokens(tokens) {
  db.run(`
    UPDATE youtube_channels
    SET access_token = ?, refresh_token = ?, token_expiry = ?
  `, [
    tokens.access_token,
    tokens.refresh_token || db.get('SELECT refresh_token FROM youtube_channels LIMIT 1')?.refresh_token,
    tokens.expiry_date ? Math.floor(tokens.expiry_date / 1000) : null,
  ]);
}

function disconnectChannel() {
  db.run('DELETE FROM youtube_channels');
}

// ── Helpers ───────────────────────────────────────────────────

function formatCount(n) {
  const num = parseInt(n) || 0;
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1)}M`;
  if (num >= 1_000)     return `${(num / 1_000).toFixed(1)}K`;
  return `${num}`;
}

module.exports = {
  getAuthUrl,
  exchangeCode,
  getChannelInfo,
  uploadShort,
  listUploads,
  getVideoAnalytics,
  saveChannelToDB,
  getStoredChannel,
  updateStoredTokens,
  disconnectChannel,
};
