// ============================================================
//  services/scheduler.js
//  Autopilot engine: auto-generates Shorts from trends,
//  posts scheduled Shorts to YouTube, and refreshes trend data.
// ============================================================
const cron          = require('node-cron');
const db            = require('../utils/database');
const logger        = require('../utils/logger');
const trendsService = require('./trendsService');
const generatorService = require('./generatorService');
const youtubeService   = require('./youtubeService');
const path          = require('path');
const fs            = require('fs');

const TRENDS_CRON    = process.env.TRENDS_REFRESH_CRON || '0 */2 * * *'; // Every 2 hours
const SCHEDULER_CRON = process.env.SCHEDULER_CRON      || '* * * * *';   // Every minute
const AUTOPILOT_CRON = '0 */6 * * *';                                     // Every 6 hours

let trendsJob    = null;
let schedulerJob = null;
let autopilotJob = null;

function start() {
  // 1. Refresh trending data every 2 hours
  trendsJob = cron.schedule(TRENDS_CRON, async () => {
    await runSafe('trends-refresh', refreshTrends);
  });

  // 2. Post scheduled Shorts every minute
  schedulerJob = cron.schedule(SCHEDULER_CRON, async () => {
    await runSafe('scheduled-posts', postScheduledShorts);
  });

  // 3. Autopilot: auto-generate Shorts every 6 hours (if enabled)
  autopilotJob = cron.schedule(AUTOPILOT_CRON, async () => {
    await runSafe('autopilot', runAutopilot);
  });

  logger.info(`Scheduler started — Trends: ${TRENDS_CRON} | Posts: ${SCHEDULER_CRON} | Autopilot: ${AUTOPILOT_CRON}`);

  // Fetch trends on startup
  setTimeout(() => runSafe('trends-refresh-startup', refreshTrends), 5000);
}

function stop() {
  trendsJob?.stop();
  schedulerJob?.stop();
  autopilotJob?.stop();
  logger.info('Scheduler stopped');
}

// ── Job: Refresh Google Trends ────────────────────────────────

async function refreshTrends() {
  const regions = ['US', 'GB', 'IN', 'AU', 'CA'];
  for (const region of regions) {
    try {
      await trendsService.getTrends({ region, forceRefresh: true });
      logger.info(`Trends refreshed for ${region}`);
    } catch (err) {
      logger.error(`Trend refresh failed for ${region}: ${err.message}`);
    }
  }
}

// ── Job: Post scheduled Shorts ────────────────────────────────

async function postScheduledShorts() {
  const now = Math.floor(Date.now() / 1000);

  const due = db.all(`
    SELECT * FROM shorts
    WHERE status = 'scheduled'
      AND scheduled_at IS NOT NULL
      AND scheduled_at <= ?
    ORDER BY scheduled_at ASC
    LIMIT 5
  `, [now]);

  if (due.length === 0) return;
  logger.info(`Found ${due.length} Short(s) due for posting`);

  const stored = youtubeService.getStoredChannel();
  if (!stored) {
    logger.warn('Cannot post — no YouTube channel connected');
    return;
  }

  for (const short of due) {
    try {
      await postShortToYouTube(short, stored.tokens);
    } catch (err) {
      logger.error(`Failed to post Short ${short.id}: ${err.message}`);
      db.run('UPDATE shorts SET status = ? WHERE id = ?', ['failed', short.id]);
      logSchedulerEvent('scheduled-posts', 'error', `Short ${short.id}: ${err.message}`);
    }
  }
}

// ── Job: Autopilot content generation ────────────────────────

async function runAutopilot() {
  const setting = db.get("SELECT value FROM settings WHERE key = 'autopilot_enabled'");
  if (setting?.value !== 'true') return;

  const autoPost = db.get("SELECT value FROM settings WHERE key = 'autopilot_auto_post'");
  const region   = db.get("SELECT value FROM settings WHERE key = 'autopilot_region'")?.value || 'US';
  const tone     = db.get("SELECT value FROM settings WHERE key = 'autopilot_tone'")?.value    || 'educational';

  logger.info('Autopilot: starting content generation cycle');

  // Get top 3 trends
  const trends = await trendsService.getTrends({ region });
  const top3   = trends.slice(0, 3);

  for (const trend of top3) {
    try {
      // Check if we already generated a Short for this trend recently (last 24h)
      const recent = db.get(
        "SELECT id FROM shorts WHERE trend_id = ? AND created_at > ?",
        [trend.id, Math.floor(Date.now() / 1000) - 86400]
      );
      if (recent) continue;

      logger.info(`Autopilot: generating Short for "${trend.name}"`);
      const generated = await generatorService.generateShort({
        topic:    trend.name,
        category: trend.category,
        tone,
        duration: 30,
        style:    'Talking Head',
        trendId:  trend.id,
      });

      // If auto-post is enabled, schedule it for 30 minutes from now
      if (autoPost?.value === 'true') {
        const scheduledAt = Math.floor(Date.now() / 1000) + 1800; // +30 min
        db.run(
          "UPDATE shorts SET status = 'scheduled', scheduled_at = ? WHERE id = ?",
          [scheduledAt, generated.id]
        );
        logger.info(`Autopilot: Short "${generated.title}" scheduled`);
      }

      logSchedulerEvent('autopilot', 'success', `Generated Short for "${trend.name}"`);
    } catch (err) {
      logger.error(`Autopilot generation error: ${err.message}`);
      logSchedulerEvent('autopilot', 'error', err.message);
    }
  }
}

// ── Post to YouTube ───────────────────────────────────────────

async function postShortToYouTube(short, tokens) {
  // Check if there's a video file associated with this Short
  const videoPath = path.resolve(`./data/videos/${short.id}.mp4`);

  if (!fs.existsSync(videoPath)) {
    // No video file — mark as needing video rendering
    logger.warn(`Short ${short.id} has no video file. Marking as needs-video.`);
    db.run("UPDATE shorts SET status = 'needs-video' WHERE id = ?", [short.id]);
    return;
  }

  const script   = safeJsonParse(short.script, []);
  const hashtags = safeJsonParse(short.hashtags, []);

  const { videoId, videoUrl } = await youtubeService.uploadShort({
    videoFilePath:     videoPath,
    title:             short.title,
    description:       short.description || buildDescription(script),
    hashtags,
    notifySubscribers: true,
    tokens,
  });

  db.run(`
    UPDATE shorts
    SET status = 'posted', youtube_id = ?, youtube_url = ?, posted_at = ?
    WHERE id = ?
  `, [videoId, videoUrl, Math.floor(Date.now() / 1000), short.id]);

  logger.info(`Short posted: ${videoUrl}`);
  logSchedulerEvent('scheduled-posts', 'success', `Posted Short ${short.id} → ${videoUrl}`);
}

// ── Helpers ───────────────────────────────────────────────────

async function runSafe(name, fn) {
  try {
    await fn();
  } catch (err) {
    logger.error(`Scheduler job "${name}" failed: ${err.message}`);
    logSchedulerEvent(name, 'error', err.message);
  }
}

function logSchedulerEvent(job, status, message) {
  try {
    db.run(
      'INSERT INTO scheduler_log (job, status, message, ran_at) VALUES (?,?,?,?)',
      [job, status, message, Math.floor(Date.now() / 1000)]
    );
  } catch {}
}

function buildDescription(script) {
  return script.map(s => s.text).join(' ').slice(0, 300);
}

function safeJsonParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

// ── Manual triggers (for API) ─────────────────────────────────

async function triggerTrendsRefresh()  { return runSafe('manual-trends', refreshTrends); }
async function triggerAutopilot()      { return runSafe('manual-autopilot', runAutopilot); }
async function triggerPostScheduled()  { return runSafe('manual-post', postScheduledShorts); }

module.exports = {
  start, stop,
  triggerTrendsRefresh,
  triggerAutopilot,
  triggerPostScheduled,
};
