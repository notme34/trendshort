// js/data.js — Static fallback data for demo / offline mode
// This file is intentionally minimal; all live data comes from the backend.
window.MOCK_READY = true;
