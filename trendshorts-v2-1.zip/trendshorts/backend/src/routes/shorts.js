// ============================================================
//  routes/shorts.js — CRUD for the Shorts library
// ============================================================
const express = require('express');
const router  = express.Router();
const db      = require('../utils/database');

function parseShort(row) {
  return {
    ...row,
    script:     safeJsonParse(row.script, []),
    storyboard: safeJsonParse(row.storyboard, []),
    hashtags:   safeJsonParse(row.hashtags, []),
  };
}

// GET /api/shorts?status=all&category=all&search=&page=1&limit=12
router.get('/', (req, res) => {
  const { status = 'all', category = 'all', search = '', page = 1, limit = 12 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let where  = [];
  let params = [];

  if (status !== 'all') { where.push("status = ?");   params.push(status); }
  if (category !== 'all') { where.push("category = ?"); params.push(category); }
  if (search)  { where.push("title LIKE ?"); params.push(`%${search}%`); }

  const whereClause = where.length ? 'WHERE ' + where.join(' AND ') : '';

  const total  = db.get(`SELECT COUNT(*) as n FROM shorts ${whereClause}`, params)?.n || 0;
  const rows   = db.all(
    `SELECT * FROM shorts ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    [...params, parseInt(limit), offset]
  );

  res.json({ success: true, total, page: parseInt(page), shorts: rows.map(parseShort) });
});

// GET /api/shorts/:id
router.get('/:id', (req, res) => {
  const row = db.get('SELECT * FROM shorts WHERE id = ?', [req.params.id]);
  if (!row) return res.status(404).json({ error: 'Short not found' });
  res.json({ success: true, short: parseShort(row) });
});

// PATCH /api/shorts/:id  — update title, description, status, etc.
router.patch('/:id', (req, res) => {
  const allowed = ['title', 'description', 'status', 'tone', 'style'];
  const updates = Object.entries(req.body)
    .filter(([k]) => allowed.includes(k));

  if (updates.length === 0) return res.status(400).json({ error: 'No valid fields to update' });

  const setClauses = updates.map(([k]) => `${k} = ?`).join(', ');
  const values     = updates.map(([, v]) => v);

  db.run(`UPDATE shorts SET ${setClauses} WHERE id = ?`, [...values, req.params.id]);
  const updated = db.get('SELECT * FROM shorts WHERE id = ?', [req.params.id]);
  res.json({ success: true, short: parseShort(updated) });
});

// DELETE /api/shorts/:id
router.delete('/:id', (req, res) => {
  const row = db.get('SELECT id FROM shorts WHERE id = ?', [req.params.id]);
  if (!row) return res.status(404).json({ error: 'Short not found' });
  db.run('DELETE FROM shorts WHERE id = ?', [req.params.id]);
  res.json({ success: true });
});

// GET /api/shorts/stats/summary  — dashboard stats
router.get('/stats/summary', (req, res) => {
  const total     = db.get("SELECT COUNT(*) as n FROM shorts")?.n || 0;
  const posted    = db.get("SELECT COUNT(*) as n FROM shorts WHERE status = 'posted'")?.n || 0;
  const scheduled = db.get("SELECT COUNT(*) as n FROM shorts WHERE status = 'scheduled'")?.n || 0;
  const draft     = db.get("SELECT COUNT(*) as n FROM shorts WHERE status = 'draft'")?.n || 0;
  res.json({ success: true, stats: { total, posted, scheduled, draft } });
});

function safeJsonParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

module.exports = router;
