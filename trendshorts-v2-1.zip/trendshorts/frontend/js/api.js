// ============================================================
//  js/api.js — TrendShorts Frontend API Client
//  Connects the frontend to the Express backend.
//  Set window.TRENDSHORTS_API_URL before including this file
//  if your backend runs on a different URL/port.
// ============================================================

const API_BASE = window.TRENDSHORTS_API_URL || 'http://localhost:3001';

async function apiFetch(path, opts = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts,
    body: opts.body && typeof opts.body === 'object' ? JSON.stringify(opts.body) : opts.body,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

const TrendShortsAPI = {
  async getTrends({ region = 'US', category = 'all', forceRefresh = false } = {}) {
    const p = new URLSearchParams({ region, category, forceRefresh });
    const d = await apiFetch(`/api/trends?${p}`);
    return d.trends || [];
  },
  async searchTrends(q, region = 'US') {
    return apiFetch(`/api/trends/search?${new URLSearchParams({ q, region })}`);
  },
  async refreshTrends() { return apiFetch('/api/trends/refresh', { method: 'POST' }); },
  async generateShort(opts) {
    const d = await apiFetch('/api/generator/generate', { method: 'POST', body: opts });
    return d.short;
  },
  async getShorts(opts = {}) {
    return apiFetch(`/api/shorts?${new URLSearchParams(opts)}`);
  },
  async updateShort(id, updates) {
    const d = await apiFetch(`/api/shorts/${id}`, { method: 'PATCH', body: updates });
    return d.short;
  },
  async deleteShort(id) { return apiFetch(`/api/shorts/${id}`, { method: 'DELETE' }); },
  async getShortStats() {
    const d = await apiFetch('/api/shorts/stats/summary');
    return d.stats;
  },
  async postShortNow(shortId, opts = {}) {
    return apiFetch(`/api/youtube/post/${shortId}`, { method: 'POST', body: opts });
  },
  async scheduleShort(shortId, scheduledAt) {
    return apiFetch(`/api/youtube/schedule/${shortId}`, { method: 'POST', body: { scheduledAt } });
  },
  async cancelSchedule(shortId) {
    return apiFetch(`/api/youtube/schedule/${shortId}`, { method: 'DELETE' });
  },
  async uploadVideoFile(shortId, file) {
    const form = new FormData();
    form.append('video', file);
    const res = await fetch(`${API_BASE}/api/youtube/upload/${shortId}`, {
      method: 'POST', credentials: 'include', body: form,
    });
    if (!res.ok) throw new Error('Upload failed');
    return res.json();
  },
  async getDashboardAnalytics() { return apiFetch('/api/analytics/dashboard'); },
  async getYouTubeAnalytics()   { return apiFetch('/api/analytics/youtube'); },
  async getSettings() {
    const d = await apiFetch('/api/settings');
    return d.settings;
  },
  async updateSettings(settings) {
    return apiFetch('/api/settings', { method: 'PUT', body: settings });
  },
  async triggerAutopilot() {
    return apiFetch('/api/settings/autopilot/trigger', { method: 'POST' });
  },
  async health() { return apiFetch('/api/health'); },
};

const TrendShortsAuth = {
  async getYouTubeAuthUrl() {
    const { url } = await apiFetch('/api/auth/youtube/url');
    return url;
  },
  async getYouTubeStatus() { return apiFetch('/api/auth/youtube/status'); },
  async disconnectYouTube() {
    return apiFetch('/api/auth/youtube/disconnect', { method: 'POST' });
  },
  async refreshChannel() {
    return apiFetch('/api/auth/youtube/refresh', { method: 'POST' });
  },
};

// Auto-detect backend on load
(async function autoConnect() {
  try {
    await TrendShortsAPI.health();
    window.__backendReady = true;
    console.log('[TrendShorts] ✅ Backend connected');

    // Handle OAuth callback
    const params = new URLSearchParams(window.location.search);
    if (params.get('auth') === 'success') {
      history.replaceState({}, '', window.location.pathname);
      window.dispatchEvent(new CustomEvent('youtube:connected', {
        detail: { channelName: params.get('channel') },
      }));
    }
    if (params.get('auth') === 'denied') {
      window.dispatchEvent(new CustomEvent('youtube:denied'));
    }
  } catch {
    window.__backendReady = false;
    console.log('[TrendShorts] ⚠️  Backend not reachable — running in demo mode');
  }
})();

window.TrendShortsAPI  = TrendShortsAPI;
window.TrendShortsAuth = TrendShortsAuth;
