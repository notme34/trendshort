// ============================================================
//  services/generatorService.js
//  Generates Short scripts, storyboards, and titles via OpenAI
// ============================================================
const axios  = require('axios');
const { v4: uuidv4 } = require('uuid');
const db     = require('../utils/database');
const logger = require('../utils/logger');

const OPENAI_KEY = process.env.OPENAI_API_KEY;

// ── Main generator ────────────────────────────────────────────

/**
 * Generates a complete YouTube Short package from a topic.
 * @param {Object} opts
 * @param {string} opts.topic
 * @param {string} opts.category
 * @param {string} opts.tone         - educational | entertaining | inspirational | news | tutorial
 * @param {number} opts.duration     - 15 | 30 | 45 | 60 (seconds)
 * @param {string} opts.style        - Talking Head | Slideshow | Animated Text | Voiceover + B-roll
 * @param {string} opts.audience
 * @param {string[]} opts.keywords
 * @param {number|null} opts.trendId
 */
async function generateShort(opts) {
  const {
    topic, category = 'general', tone = 'educational',
    duration = 30, style = 'Talking Head',
    audience = 'General audience', keywords = [],
    trendId = null,
  } = opts;

  let result;
  if (OPENAI_KEY) {
    result = await generateWithOpenAI(opts);
  } else {
    logger.warn('OPENAI_API_KEY not set — using template-based generation');
    result = generateWithTemplate(opts);
  }

  // Persist to database
  const id = uuidv4();
  db.run(`
    INSERT INTO shorts
      (id, title, description, category, tone, duration, style, score,
       script, storyboard, hashtags, status, trend_id, created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `, [
    id, result.title, result.description, category, tone,
    `${duration}s`, style, result.score,
    JSON.stringify(result.script),
    JSON.stringify(result.storyboard),
    JSON.stringify(result.hashtags),
    'draft', trendId,
    Math.floor(Date.now() / 1000),
  ]);

  return { id, ...result };
}

// ── OpenAI generation ─────────────────────────────────────────

async function generateWithOpenAI({ topic, category, tone, duration, style, audience, keywords }) {
  const sceneCount = duration <= 15 ? 3 : duration <= 30 ? 5 : duration <= 45 ? 6 : 8;
  const kwStr      = keywords.length ? `Key keywords: ${keywords.join(', ')}.` : '';

  const systemPrompt = `You are an expert YouTube Shorts content creator. 
You write viral, engaging scripts optimised for short-form vertical video.
Always respond with valid JSON only — no markdown, no commentary.`;

  const userPrompt = `Create a complete YouTube Short package for this topic:

Topic: "${topic}"
Category: ${category}
Tone: ${tone}
Duration: ${duration} seconds
Style: ${style}
Target audience: ${audience}
${kwStr}

Return a JSON object with exactly these fields:
{
  "title": "Catchy title under 70 chars with an emoji",
  "description": "2-sentence description for the video description box",
  "score": <virality score 0-100 integer>,
  "script": [
    { "time": "0:00", "action": "HOOK", "text": "Opening line..." },
    ... (${sceneCount} total scenes with actions: HOOK, CONTEXT, MAIN_POINT, EXAMPLE, CTA, OUTRO)
  ],
  "storyboard": [
    { "num": 1, "emoji": "🎬", "desc": "Visual direction for this scene", "timeStart": "0:00" },
    ... (${sceneCount} entries matching the script)
  ],
  "hashtags": ["#Tag1", "#Tag2", ... (10-15 relevant hashtags)]
}`;

  const response = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user',   content: userPrompt },
    ],
    temperature:  0.8,
    max_tokens:   2000,
    response_format: { type: 'json_object' },
  }, {
    headers: {
      'Authorization': `Bearer ${OPENAI_KEY}`,
      'Content-Type':  'application/json',
    },
    timeout: 30000,
  });

  const raw = response.data.choices[0].message.content;
  const parsed = JSON.parse(raw);

  // Validate and sanitise
  return {
    title:       parsed.title       || `${topic} — Watch This`,
    description: parsed.description || `Everything you need to know about ${topic}.`,
    score:       Math.min(100, Math.max(0, parseInt(parsed.score) || 70)),
    script:      Array.isArray(parsed.script)      ? parsed.script      : [],
    storyboard:  Array.isArray(parsed.storyboard)  ? parsed.storyboard  : [],
    hashtags:    Array.isArray(parsed.hashtags)    ? parsed.hashtags    : [],
  };
}

// ── Template-based fallback ───────────────────────────────────

function generateWithTemplate({ topic, category, tone, duration, keywords }) {
  const sceneCount = duration <= 15 ? 3 : duration <= 30 ? 5 : 8;
  const titleEmoji = { technology: '🤖', entertainment: '🎬', sports: '⚽', science: '🔬', health: '💪', business: '📈', gaming: '🎮', food: '🍔', travel: '✈️', fashion: '👗' }[category] || '🔥';
  const toneVerb   = { educational: 'explains', entertaining: 'breaks down', inspirational: 'reveals', news: 'reports on', tutorial: 'teaches' }[tone] || 'covers';

  const script = [
    { time: '0:00', action: 'HOOK',       text: `Wait — everything you know about ${topic} is about to change. Here's what nobody tells you.` },
    { time: '0:05', action: 'CONTEXT',    text: `${topic} has been trending for a reason. Millions of people are searching for this right now.` },
    { time: '0:12', action: 'MAIN_POINT', text: `Here's the key thing: ${topic} is reshaping how we think about ${category}. And it's happening faster than you think.` },
    { time: '0:22', action: 'EXAMPLE',    text: `For example, take what happened last week. Real-world impact is already being felt by millions.` },
    { time: '0:35', action: 'CTA',        text: `If this surprised you, smash the like button and follow for more insights like this every day.` },
  ].slice(0, sceneCount);

  const storyboard = script.map((s, i) => ({
    num:       i + 1,
    emoji:     ['🎬','📱','💡','📊','📣','✅'][i] || '🎬',
    desc:      `${s.action}: ${s.text.slice(0, 60)}…`,
    timeStart: s.time,
  }));

  const baseHashtags = [`#${topic.replace(/\s+/g, '')}`, `#${category}`, '#shorts', '#trending', '#viral'];
  const kwHashtags   = keywords.map(k => `#${k.replace(/\s+/g, '')}`);
  const hashtags     = [...new Set([...baseHashtags, ...kwHashtags, '#youtube', '#fyp', '#explore'])].slice(0, 15);

  return {
    title:       `${titleEmoji} ${topic}: The Truth Nobody ${toneVerb}`,
    description: `This Short ${toneVerb} the most important things about ${topic}. Don't miss out on what's trending.`,
    score:       Math.floor(Math.random() * 20) + 70, // 70–90
    script,
    storyboard,
    hashtags,
  };
}

// ── Get a short by ID ─────────────────────────────────────────

function getShortById(id) {
  const row = db.get('SELECT * FROM shorts WHERE id = ?', [id]);
  if (!row) return null;
  return parseShortRow(row);
}

function parseShortRow(row) {
  return {
    ...row,
    script:     safeJsonParse(row.script, []),
    storyboard: safeJsonParse(row.storyboard, []),
    hashtags:   safeJsonParse(row.hashtags, []),
  };
}

function safeJsonParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

module.exports = { generateShort, getShortById, parseShortRow };
