// ============================================================
//  routes/settings.js — App settings + autopilot config
// ============================================================
const express   = require('express');
const router    = express.Router();
const db        = require('../utils/database');
const scheduler = require('../services/scheduler');

// GET /api/settings
router.get('/', (req, res) => {
  const rows = db.all('SELECT key, value FROM settings');
  const settings = Object.fromEntries(rows.map(r => [r.key, r.value]));
  res.json({ success: true, settings });
});

// PUT /api/settings  — bulk update settings
router.put('/', (req, res) => {
  const entries = Object.entries(req.body);
  if (!entries.length) return res.status(400).json({ error: 'No settings provided' });

  db.transaction(() => {
    for (const [key, value] of entries) {
      db.run(
        "INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        [key, String(value)]
      );
    }
  });

  res.json({ success: true });
});

// POST /api/settings/autopilot/trigger  — manually run autopilot
router.post('/autopilot/trigger', async (req, res) => {
  try {
    await scheduler.triggerAutopilot();
    res.json({ success: true, message: 'Autopilot cycle triggered' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
