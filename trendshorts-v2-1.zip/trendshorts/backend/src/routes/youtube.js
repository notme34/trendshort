// ============================================================
//  routes/youtube.js — Upload and manage YouTube videos
// ============================================================
const express  = require('express');
const router   = express.Router();
const multer   = require('multer');
const path     = require('path');
const fs       = require('fs');
const youtube  = require('../services/youtubeService');
const db       = require('../utils/database');
const logger   = require('../utils/logger');

// Ensure video upload dir exists
const VIDEO_DIR = path.resolve('./data/videos');
if (!fs.existsSync(VIDEO_DIR)) fs.mkdirSync(VIDEO_DIR, { recursive: true });

// Multer config — save uploaded videos to data/videos/{shortId}.mp4
const storage = multer.diskStorage({
  destination: VIDEO_DIR,
  filename: (req, file, cb) => {
    const shortId = req.params.id || req.body.shortId || `upload_${Date.now()}`;
    cb(null, `${shortId}.mp4`);
  },
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'video/mp4') cb(null, true);
    else cb(new Error('Only MP4 files are accepted'), false);
  },
  limits: { fileSize: 256 * 1024 * 1024 }, // 256 MB
});

// GET /api/youtube/channel
router.get('/channel', (req, res) => {
  const stored = youtube.getStoredChannel();
  if (!stored) return res.json({ connected: false });
  res.json({ connected: true, channel: stored.channel });
});

// GET /api/youtube/uploads
router.get('/uploads', async (req, res) => {
  const stored = youtube.getStoredChannel();
  if (!stored) return res.status(401).json({ error: 'No YouTube channel connected' });
  try {
    const videos = await youtube.listUploads(stored.tokens, parseInt(req.query.max) || 20);
    res.json({ success: true, videos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/youtube/upload/:id  — attach a video file to a Short
router.post('/upload/:id', upload.single('video'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No video file provided' });
  logger.info(`Video file saved for Short ${req.params.id}: ${req.file.path}`);
  res.json({ success: true, path: req.file.path, shortId: req.params.id });
});

// POST /api/youtube/post/:id  — immediately post a Short to YouTube
router.post('/post/:id', async (req, res) => {
  const stored = youtube.getStoredChannel();
  if (!stored) return res.status(401).json({ error: 'No YouTube channel connected. Connect via /api/auth/youtube/url' });

  const short = db.get('SELECT * FROM shorts WHERE id = ?', [req.params.id]);
  if (!short) return res.status(404).json({ error: 'Short not found' });

  const videoPath = path.resolve(`./data/videos/${short.id}.mp4`);
  if (!fs.existsSync(videoPath)) {
    return res.status(422).json({
      error: 'No video file found for this Short.',
      hint:  `Upload an MP4 first via POST /api/youtube/upload/${short.id}`,
    });
  }

  try {
    const hashtags = safeJsonParse(short.hashtags, []);
    const { videoId, videoUrl } = await youtube.uploadShort({
      videoFilePath:     videoPath,
      title:             short.title,
      description:       short.description || '',
      hashtags,
      notifySubscribers: req.body.notifySubscribers !== false,
      madeForKids:       req.body.madeForKids === true,
      tokens:            stored.tokens,
    });

    db.run(
      "UPDATE shorts SET status = 'posted', youtube_id = ?, youtube_url = ?, posted_at = ? WHERE id = ?",
      [videoId, videoUrl, Math.floor(Date.now() / 1000), short.id]
    );

    res.json({ success: true, videoId, videoUrl });
  } catch (err) {
    db.run("UPDATE shorts SET status = 'failed' WHERE id = ?", [short.id]);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/youtube/schedule/:id  — schedule a Short for future posting
router.post('/schedule/:id', (req, res) => {
  const { scheduledAt } = req.body; // ISO datetime string or Unix timestamp
  if (!scheduledAt) return res.status(400).json({ error: 'scheduledAt is required' });

  const ts = typeof scheduledAt === 'number'
    ? scheduledAt
    : Math.floor(new Date(scheduledAt).getTime() / 1000);

  if (isNaN(ts) || ts <= Math.floor(Date.now() / 1000)) {
    return res.status(400).json({ error: 'scheduledAt must be a future datetime' });
  }

  const short = db.get('SELECT id FROM shorts WHERE id = ?', [req.params.id]);
  if (!short) return res.status(404).json({ error: 'Short not found' });

  db.run("UPDATE shorts SET status = 'scheduled', scheduled_at = ? WHERE id = ?", [ts, req.params.id]);
  res.json({ success: true, scheduledAt: ts });
});

// DELETE /api/youtube/schedule/:id  — cancel a scheduled post
router.delete('/schedule/:id', (req, res) => {
  db.run("UPDATE shorts SET status = 'draft', scheduled_at = NULL WHERE id = ? AND status = 'scheduled'", [req.params.id]);
  res.json({ success: true });
});

function safeJsonParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

module.exports = router;
